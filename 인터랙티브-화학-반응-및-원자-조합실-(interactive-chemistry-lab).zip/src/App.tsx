import React, { useState, useEffect } from 'react';
import {
  Substance,
  ChemicalReaction,
  Quest,
} from './types';
import { SUBSTANCES, REACTIONS, QUESTS, calculateLiquidState } from './utils/chemistryData';
import { soundManager } from './utils/audio';
import { LabBeaker } from './components/LabBeaker';
import { ChemicalInventory } from './components/ChemicalInventory';
import { MoleculeViewer3D } from './components/MoleculeViewer3D';
import { ReactionResultModal } from './components/ReactionResultModal';
import { PhScaleGuide } from './components/PhScaleGuide';
import { QuestBook } from './components/QuestBook';
import { AtomBuilderMini } from './components/AtomBuilderMini';
import {
  FlaskConical,
  Atom,
  Trophy,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  Info,
  Activity,
  Award,
  AlertTriangle,
  Lightbulb,
  CheckCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  // Beaker state
  const [beakerContents, setBeakerContents] = useState<{ [id: string]: number }>({});
  const [temperature, setTemperature] = useState<number>(20.0);
  const [isHeating, setIsHeating] = useState<boolean>(false);
  const [isElectrifying, setIsElectrifying] = useState<boolean>(false);
  const [isReacting, setIsReacting] = useState<boolean>(false);

  // Sound state
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Quest & Discovery state
  const [completedQuestIds, setCompletedQuestIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('chem_completed_quests');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [discoveredReactionIds, setDiscoveredReactionIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('chem_discovered_reactions');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeQuest, setActiveQuest] = useState<Quest | null>(null);

  // Modals state
  const [activeModal, setActiveModal] = useState<
    'none' | 'reaction' | 'inspectSubstance' | 'phGuide' | 'quests' | 'atomBuilder'
  >('none');
  const [selectedSubstance, setSelectedSubstance] = useState<Substance | null>(null);
  const [currentReactionResult, setCurrentReactionResult] = useState<ChemicalReaction | null>(null);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'info' | 'warn' | 'success' } | null>(null);

  // Save progress
  useEffect(() => {
    try {
      localStorage.setItem('chem_completed_quests', JSON.stringify(completedQuestIds));
    } catch {}
  }, [completedQuestIds]);

  useEffect(() => {
    try {
      localStorage.setItem('chem_discovered_reactions', JSON.stringify(discoveredReactionIds));
    } catch {}
  }, [discoveredReactionIds]);

  // Temperature simulation timer (heating up or slowly cooling down to 20°C)
  useEffect(() => {
    const timer = setInterval(() => {
      if (isHeating) {
        setTemperature((prev) => Math.min(100.0, prev + 1.2));
      } else {
        setTemperature((prev) => {
          if (prev > 20.2) return prev - 0.4;
          if (prev < 19.8) return prev + 0.2;
          return 20.0;
        });
      }
    }, 500);
    return () => clearInterval(timer);
  }, [isHeating]);

  const showToast = (text: string, type: 'info' | 'warn' | 'success' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Sound Mute Toggle
  const toggleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    soundManager.setMuted(newMuted);
    if (!newMuted) soundManager.playClick();
  };

  // Add substance to beaker
  const handleAddSubstance = (substanceId: string, amount: number = 1) => {
    setBeakerContents((prev) => {
      const current = prev[substanceId] || 0;
      return {
        ...prev,
        [substanceId]: current + amount,
      };
    });

    const sub = SUBSTANCES.find((s) => s.id === substanceId);
    if (sub) {
      // Check auto reactions (e.g. Na + H2O)
      setTimeout(() => {
        checkAndExecuteReaction('auto');
      }, 300);
    }
  };

  // Clear Beaker
  const handleClearBeaker = () => {
    setBeakerContents({});
    setIsHeating(false);
    setIsElectrifying(false);
    setIsReacting(false);
    showToast('비커를 깨끗이 비웠습니다.', 'info');
  };

  // Toggle Heat (Bunsen burner)
  const handleToggleHeat = () => {
    const nextHeating = !isHeating;
    setIsHeating(nextHeating);
    if (nextHeating) {
      showToast('🔥 알코올 램프를 켰습니다. 열을 받는 반응이 가능해집니다.', 'info');
      setTimeout(() => {
        checkAndExecuteReaction('heat');
      }, 400);
    }
  };

  // Toggle Electricity (Electrolysis)
  const handleToggleElectricity = () => {
    const nextElec = !isElectrifying;
    setIsElectrifying(nextElec);
    if (nextElec) {
      showToast('⚡ 전원을 켰습니다. 전해질 용액에서 전기 분해가 시작됩니다.', 'info');
      setTimeout(() => {
        checkAndExecuteReaction('electricity');
      }, 400);
    }
  };

  // Core Chemical Reaction Engine
  const checkAndExecuteReaction = (forcedCondition?: 'heat' | 'electricity' | 'stir' | 'auto') => {
    const currentCondition =
      forcedCondition ||
      (isHeating ? 'heat' : isElectrifying ? 'electricity' : 'stir');

    // Find first reaction matching reactants and condition
    let matchedReaction: ChemicalReaction | null = null;

    for (const rx of REACTIONS) {
      // Check condition compatibility
      if (rx.condition === 'heat' && !isHeating && forcedCondition !== 'heat') continue;
      if (rx.condition === 'electricity' && !isElectrifying && forcedCondition !== 'electricity') continue;

      // Check if all reactants exist with required stoichiometry
      let canReact = true;
      for (const [rId, reqRatio] of Object.entries(rx.reactants)) {
        if ((beakerContents[rId] || 0) < reqRatio) {
          canReact = false;
          break;
        }
      }

      if (canReact) {
        matchedReaction = rx;
        break;
      }
    }

    if (matchedReaction) {
      // Trigger Reaction Animation and Sounds
      setIsReacting(true);

      if (matchedReaction.soundType === 'explosion') {
        soundManager.playExplosion();
      } else if (matchedReaction.soundType === 'spark') {
        soundManager.playSpark();
      } else if (matchedReaction.soundType === 'fizz') {
        soundManager.playBubbles(1.8);
      } else {
        soundManager.playSuccess();
      }

      // Update temperature
      setTemperature((prev) => Math.min(100, Math.max(10, prev + matchedReaction!.temperatureRise)));

      // Deduct reactants & Add products
      const nextContents = { ...beakerContents };
      for (const [rId, ratio] of Object.entries(matchedReaction.reactants)) {
        nextContents[rId] = Math.max(0, (nextContents[rId] || 0) - ratio);
        if (nextContents[rId] === 0) {
          delete nextContents[rId];
        }
      }
      for (const [pId, ratio] of Object.entries(matchedReaction.products)) {
        nextContents[pId] = (nextContents[pId] || 0) + ratio;
      }

      setBeakerContents(nextContents);

      // Record discovered reaction
      if (!discoveredReactionIds.includes(matchedReaction.id)) {
        setDiscoveredReactionIds((prev) => [...prev, matchedReaction!.id]);
      }

      // Check Quests
      QUESTS.forEach((q) => {
        if (q.targetReactionId === matchedReaction!.id && !completedQuestIds.includes(q.id)) {
          setCompletedQuestIds((prev) => [...prev, q.id]);
          try {
            confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
          } catch {}
        }
      });

      setCurrentReactionResult(matchedReaction);

      setTimeout(() => {
        setIsReacting(false);
        setActiveModal('reaction');
      }, 1000);
    } else {
      // If user manually pressed "반응 시작" but no match
      if (forcedCondition === 'stir' || !forcedCondition) {
        const totalSubstances = Object.keys(beakerContents).length;
        if (totalSubstances === 0) {
          showToast('비커에 물질을 먼저 투입해주세요!', 'warn');
        } else {
          showToast(
            '조건이 맞지 않습니다. [🔥 열 가하기]나 [⚡ 전기 분해] 버튼을 누르거나 올바른 화학 원소를 조합해보세요!',
            'warn'
          );
        }
      }
    }
  };

  // Inspect Substance
  const handleInspectSubstance = (sub: Substance) => {
    soundManager.playClick();
    setSelectedSubstance(sub);
    setActiveModal('inspectSubstance');
  };

  const liquidInfo = calculateLiquidState(beakerContents);

  return (
    <div className="flex flex-col min-h-screen bg-slate-950 text-slate-100 font-sans select-none overflow-x-hidden">
      {/* Top Main Navigation Bar */}
      <header className="sticky top-0 z-30 w-full bg-slate-900/90 border-b border-slate-800/90 backdrop-blur-md px-4 py-2.5 flex items-center justify-between shadow-md">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="relative p-2 rounded-xl bg-gradient-to-tr from-cyan-600 via-teal-500 to-emerald-400 text-slate-950 shadow-lg shadow-cyan-500/20 animate-pulse">
            <Atom className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm sm:text-base font-black text-slate-100 tracking-tight flex items-center gap-1.5">
              <span>인터랙티브 화학 반응실</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/60 hidden sm:inline-block">
                Interactive Chemistry Lab
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              초·중등 화학 탐구 | 원소 조합 • pH 색변화 • 3D 분자 구조
            </p>
          </div>
        </div>

        {/* Action Controls & Navigation Badges */}
        <div className="flex items-center gap-2">
          {/* Quests Button */}
          <button
            id="open-quests-btn"
            onClick={() => {
              soundManager.playClick();
              setActiveModal('quests');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 transition-all shadow-sm active:scale-95"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">탐구 퀘스트</span>
            <span className="font-mono bg-amber-950/80 px-1.5 py-0.5 rounded text-[10px]">
              {completedQuestIds.length}/{QUESTS.length}
            </span>
          </button>

          {/* Atom Builder Mini-Lab Button */}
          <button
            id="open-atom-builder-btn"
            onClick={() => {
              soundManager.playClick();
              setActiveModal('atomBuilder');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/40 transition-all shadow-sm active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="hidden md:inline">원자 조합실</span>
          </button>

          {/* pH Guide Button */}
          <button
            id="open-ph-guide-nav-btn"
            onClick={() => {
              soundManager.playClick();
              setActiveModal('phGuide');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 transition-all shadow-sm active:scale-95"
          >
            <Activity className="w-4 h-4 text-cyan-400" />
            <span className="hidden md:inline">pH 가이드</span>
          </button>

          {/* Sound Mute Toggle */}
          <button
            id="sound-toggle-btn"
            onClick={toggleMute}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title={isMuted ? '음소거 해제' : '음소거'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>
      </header>

      {/* Active Quest Banner (if selected) */}
      {activeQuest && (
        <div className="w-full bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 border-b border-amber-500/30 px-4 py-2 flex items-center justify-between text-xs animate-fadeIn">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400 shrink-0 animate-bounce" />
            <div>
              <span className="font-bold text-amber-300 mr-2">진행 중인 미션: {activeQuest.title}</span>
              <span className="text-slate-300 hidden sm:inline">{activeQuest.description}</span>
            </div>
          </div>
          <button
            onClick={() => setActiveQuest(null)}
            className="text-[11px] text-slate-400 hover:text-slate-200 underline"
          >
            미션 닫기
          </button>
        </div>
      )}

      {/* Main Workspace Layout */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-3 sm:p-5 grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Side: Lab Stage & Reaction Beaker (7 cols) */}
        <section className="lg:col-span-7 flex flex-col gap-3 min-h-[500px]">
          {/* Reaction Beaker Glass Vessel */}
          <div className="flex-1 w-full">
            <LabBeaker
              contents={beakerContents}
              temperature={temperature}
              isHeating={isHeating}
              isElectrifying={isElectrifying}
              isReacting={isReacting}
              onToggleHeat={handleToggleHeat}
              onToggleElectricity={handleToggleElectricity}
              onTriggerReaction={() => checkAndExecuteReaction('stir')}
              onClearBeaker={handleClearBeaker}
              onDropSubstance={(subId) => handleAddSubstance(subId, 1)}
              onOpenPhGuide={() => {
                soundManager.playClick();
                setActiveModal('phGuide');
              }}
            />
          </div>

          {/* Quick Lab Helper Tips Card */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3 text-xs text-slate-400 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>💡 실험 팁:</strong> 수소(H₂) 2개 + 산소(O₂) 1개를 넣고 [🔥 열 가하기]를 누르면 물(H₂O)이 합성됩니다!
              </span>
            </div>
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveModal('quests');
              }}
              className="text-cyan-400 hover:text-cyan-300 font-semibold whitespace-nowrap text-[11px]"
            >
              퀘스트 도감 ➔
            </button>
          </div>
        </section>

        {/* Right Side: Chemical Inventory & Discovery Shelf (5 cols) */}
        <section className="lg:col-span-5 flex flex-col gap-3 min-h-[500px]">
          <ChemicalInventory
            onAddSubstance={(subId, amt) => handleAddSubstance(subId, amt)}
            onInspectSubstance={handleInspectSubstance}
          />
        </section>
      </main>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900/95 border border-cyan-500/50 shadow-2xl text-slate-100 text-xs font-semibold backdrop-blur-md animate-slideUp">
          <Info className="w-4 h-4 text-cyan-400" />
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Reaction Result Modal */}
      {activeModal === 'reaction' && currentReactionResult && (
        <ReactionResultModal
          reaction={currentReactionResult}
          onClose={() => setActiveModal('none')}
          onInspectProduct={(prod) => {
            setSelectedSubstance(prod);
            setActiveModal('inspectSubstance');
          }}
        />
      )}

      {/* Inspect Substance / 3D Molecule Modal */}
      {activeModal === 'inspectSubstance' && selectedSubstance && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/40 rounded-2xl shadow-2xl p-5 text-slate-100 flex flex-col gap-3 max-h-[90vh] overflow-y-auto">
            {selectedSubstance.moleculeModel ? (
              <MoleculeViewer3D
                model={selectedSubstance.moleculeModel}
                onClose={() => setActiveModal('none')}
              />
            ) : (
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                      {selectedSubstance.formulaDisplay}
                    </span>
                    <div>
                      <h3 className="font-bold text-slate-100">{selectedSubstance.name}</h3>
                      <p className="text-xs text-slate-400">{selectedSubstance.englishName}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveModal('none')}
                    className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
                  >
                    ✕
                  </button>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
                  {selectedSubstance.description}
                </p>
                <div className="p-3 bg-amber-950/30 rounded-xl border border-amber-500/30 text-xs text-amber-200">
                  ✨ <strong>재미있는 과학 상식:</strong> {selectedSubstance.funFact}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  handleAddSubstance(selectedSubstance.id, 1);
                  setActiveModal('none');
                }}
                className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white transition-colors"
              >
                비커에 즉시 투입하기 (+1)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* pH Scale Guide Modal */}
      {activeModal === 'phGuide' && (
        <PhScaleGuide
          currentPh={liquidInfo.ph}
          onClose={() => setActiveModal('none')}
        />
      )}

      {/* Quest Book Modal */}
      {activeModal === 'quests' && (
        <QuestBook
          completedQuestIds={completedQuestIds}
          discoveredReactionIds={discoveredReactionIds}
          onSelectQuest={(quest) => {
            setActiveQuest(quest);
            setActiveModal('none');
            showToast(`미션 '${quest.title}'을(를) 시작합니다!`, 'info');
          }}
          onInspectSubstance={(sub) => {
            setSelectedSubstance(sub);
            setActiveModal('inspectSubstance');
          }}
          onClose={() => setActiveModal('none')}
        />
      )}

      {/* Atom Builder Mini-Lab Modal */}
      {activeModal === 'atomBuilder' && (
        <AtomBuilderMini onClose={() => setActiveModal('none')} />
      )}
    </div>
  );
}
