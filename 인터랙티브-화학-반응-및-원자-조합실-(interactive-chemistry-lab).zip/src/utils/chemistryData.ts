import { ChemicalReaction, Molecule3DModel, Quest, Substance } from '../types';

export const SUBSTANCES: Substance[] = [
  {
    id: 'H2',
    name: '수소 기체',
    englishName: 'Hydrogen Gas',
    formula: 'H2',
    formulaDisplay: 'H₂',
    category: 'gas',
    state: 'gas',
    color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    liquidColor: 'rgba(6, 182, 212, 0.15)',
    glowColor: '#06b6d4',
    ph: 7.0,
    atomicOrMolarMass: 2.016,
    stateSymbol: '(g)',
    description: '우주에서 가장 가볍고 풍부한 원소. 가연성이 매우 높아 불꽃을 대면 "펑" 소리를 내며 격렬히 탑니다.',
    funFact: '수소차의 친환경 연료로 사용되며, 연소하면 오직 순수한 물(H₂O)만 생성됩니다!',
    hazard: '인화성 기체 (폭발 주의)',
    moleculeModel: {
      name: 'Hydrogen',
      koreanName: '수소 분자 (H₂)',
      formula: 'H₂',
      bondType: '공유 결합',
      bondAngle: '180° (선형)',
      geometry: '2원자 분자 (선형)',
      description: '두 개의 수소 원자가 전자 1쌍을 공유하여 헬륨과 같은 안정한 전자 배치를 이룹니다.',
      atoms: [
        { id: 'h1', element: 'H', name: '수소 (H)', color: '#E0F2FE', radius: 24, x: -38, y: 0, z: 0 },
        { id: 'h2', element: 'H', name: '수소 (H)', color: '#E0F2FE', radius: 24, x: 38, y: 0, z: 0 },
      ],
      bonds: [{ from: 'h1', to: 'h2', order: 1 }],
    },
  },
  {
    id: 'O2',
    name: '산소 기체',
    englishName: 'Oxygen Gas',
    formula: 'O2',
    formulaDisplay: 'O₂',
    category: 'gas',
    state: 'gas',
    color: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    liquidColor: 'rgba(244, 63, 94, 0.15)',
    glowColor: '#f43f5e',
    ph: 7.0,
    atomicOrMolarMass: 32.0,
    stateSymbol: '(g)',
    description: '우리가 숨 쉬는 데 꼭 필요한 조연성 기체로, 다른 물질이 타는 것을 도와줍니다.',
    funFact: '지구 대기의 약 21%를 차지하며, 꺼져가는 깜부기불을 다시 활활 타오르게 만듭니다.',
    hazard: '조연성 기체 (연소 촉진)',
    moleculeModel: {
      name: 'Oxygen',
      koreanName: '산소 분자 (O₂)',
      formula: 'O₂',
      bondType: '공유 결합',
      bondAngle: '180° (선형)',
      geometry: '2원자 분자 (이중 결합)',
      description: '산소 원자 2개가 전자 2쌍을 공유하는 이중 결합을 형성하여 옥텟 규칙(8전자)을 만족합니다.',
      atoms: [
        { id: 'o1', element: 'O', name: '산소 (O)', color: '#EF4444', radius: 30, x: -42, y: 0, z: 0 },
        { id: 'o2', element: 'O', name: '산소 (O)', color: '#EF4444', radius: 30, x: 42, y: 0, z: 0 },
      ],
      bonds: [{ from: 'o1', to: 'o2', order: 2 }],
    },
  },
  {
    id: 'Na',
    name: '나트륨 (소듐)',
    englishName: 'Sodium Metal',
    formula: 'Na',
    formulaDisplay: 'Na',
    category: 'metal',
    state: 'solid',
    color: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    liquidColor: 'rgba(168, 85, 247, 0.25)',
    glowColor: '#a855f7',
    ph: 7.0,
    atomicOrMolarMass: 22.99,
    stateSymbol: '(s)',
    description: '은백색의 부드러운 알칼리 금속. 칼로 쉽게 잘리며 공기 중의 산소나 물과 폭발적으로 반응합니다.',
    funFact: '물 위에 띄우면 수소 기체를 뿜어내며 동그랗게 녹아 이리저리 빠르게 돌아다닙니다!',
    hazard: '물 반응성 화재 위험 (석유 속에 보관)',
    moleculeModel: {
      name: 'Sodium',
      koreanName: '나트륨 금속 결정 (Na)',
      formula: 'Na',
      bondType: '금속 결합',
      geometry: '체심 입방 격자 (BCC)',
      description: '나트륨 양이온(Na⁺) 사이를 자유 전자들이 자유롭게 이동하며 강한 금속 결합을 형성합니다.',
      atoms: [
        { id: 'na_c', element: 'Na', name: '나트륨 (Na)', color: '#A855F7', radius: 34, x: 0, y: 0, z: 0 },
        { id: 'na_1', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: -45, y: -45, z: -45 },
        { id: 'na_2', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: 45, y: -45, z: -45 },
        { id: 'na_3', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: -45, y: 45, z: -45 },
        { id: 'na_4', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: 45, y: 45, z: -45 },
        { id: 'na_5', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: -45, y: -45, z: 45 },
        { id: 'na_6', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: 45, y: -45, z: 45 },
        { id: 'na_7', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: -45, y: 45, z: 45 },
        { id: 'na_8', element: 'Na', name: '나트륨 (Na)', color: '#C084FC', radius: 26, x: 45, y: 45, z: 45 },
      ],
      bonds: [
        { from: 'na_c', to: 'na_1', order: 1 },
        { from: 'na_c', to: 'na_2', order: 1 },
        { from: 'na_c', to: 'na_3', order: 1 },
        { from: 'na_c', to: 'na_4', order: 1 },
        { from: 'na_c', to: 'na_5', order: 1 },
        { from: 'na_c', to: 'na_6', order: 1 },
        { from: 'na_c', to: 'na_7', order: 1 },
        { from: 'na_c', to: 'na_8', order: 1 },
      ],
    },
  },
  {
    id: 'Cl2',
    name: '염소 기체',
    englishName: 'Chlorine Gas',
    formula: 'Cl2',
    formulaDisplay: 'Cl₂',
    category: 'gas',
    state: 'gas',
    color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    liquidColor: 'rgba(16, 185, 129, 0.25)',
    glowColor: '#10b981',
    ph: 5.5,
    atomicOrMolarMass: 70.9,
    stateSymbol: '(g)',
    description: '특유의 톡 쏘는 냄새가 나는 황록색의 유독 기체. 수영장 소독이나 표백제에 널리 쓰입니다.',
    funFact: '반응성이 매우 커서 나트륨 금속과 만나면 눈부신 불꽃을 내며 맛있는 소금(NaCl)이 됩니다!',
    hazard: '유독성 및 자극성 기체',
    moleculeModel: {
      name: 'Chlorine',
      koreanName: '염소 분자 (Cl₂)',
      formula: 'Cl₂',
      bondType: '공유 결합',
      bondAngle: '180° (선형)',
      geometry: '2원자 분자',
      description: '염소 원자 2개가 단일 결합을 통해 각각 최외각 전자 8개(옥텟)를 완성합니다.',
      atoms: [
        { id: 'cl1', element: 'Cl', name: '염소 (Cl)', color: '#10B981', radius: 32, x: -44, y: 0, z: 0 },
        { id: 'cl2', element: 'Cl', name: '염소 (Cl)', color: '#10B981', radius: 32, x: 44, y: 0, z: 0 },
      ],
      bonds: [{ from: 'cl1', to: 'cl2', order: 1 }],
    },
  },
  {
    id: 'HCl',
    name: '염산 (염화수소 수용액)',
    englishName: 'Hydrochloric Acid',
    formula: 'HCl',
    formulaDisplay: 'HCl',
    category: 'acid',
    state: 'aqueous',
    color: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    liquidColor: 'rgba(245, 158, 11, 0.35)',
    glowColor: '#f59e0b',
    ph: 1.0,
    atomicOrMolarMass: 36.46,
    stateSymbol: '(aq)',
    description: '대표적인 강산성 용액(pH 1). 물에 녹으면 H⁺(수소 이온)과 Cl⁻로 100% 이온화됩니다.',
    funFact: '우리 위장 속 위액에도 염산이 들어있어 음식물을 소독하고 단백질 소화를 돕습니다!',
    hazard: '강산성 부식 위험 (손에 닿지 않게 주의)',
    moleculeModel: {
      name: 'Hydrochloric Acid',
      koreanName: '염화수소 분자 (HCl)',
      formula: 'HCl',
      bondType: '공유 결합',
      bondAngle: '180° (극성 공유결합)',
      geometry: '극성 이원자 분자',
      description: '전기음성도가 큰 염소(Cl) 쪽으로 공유 전자쌍이 쏠려 강한 극성을 띱니다.',
      atoms: [
        { id: 'h', element: 'H', name: '수소 (H⁺)', color: '#E0F2FE', radius: 22, x: -40, y: 0, z: 0 },
        { id: 'cl', element: 'Cl', name: '염소 (Cl⁻)', color: '#10B981', radius: 34, x: 26, y: 0, z: 0 },
      ],
      bonds: [{ from: 'h', to: 'cl', order: 1 }],
    },
  },
  {
    id: 'NaOH',
    name: '수산화나트륨 (가성소다)',
    englishName: 'Sodium Hydroxide',
    formula: 'NaOH',
    formulaDisplay: 'NaOH',
    category: 'base',
    state: 'aqueous',
    color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
    liquidColor: 'rgba(99, 102, 241, 0.35)',
    glowColor: '#6366f1',
    ph: 13.5,
    atomicOrMolarMass: 40.0,
    stateSymbol: '(aq)',
    description: '대표적인 강염기성 용액(pH 13~14). 물에 녹아 OH⁻(수산화 이온)을 내놓으며 단백질을 녹입니다.',
    funFact: '손에 묻으면 미끌미끌한 느낌이 나며, 비누와 배수관 세척제의 주원료입니다.',
    hazard: '강염기 부식 위험 (단백질 용해)',
    moleculeModel: {
      name: 'Sodium Hydroxide',
      koreanName: '수산화나트륨 (NaOH)',
      formula: 'NaOH',
      bondType: '이온 결합',
      geometry: 'Na⁺ 와 OH⁻의 결합',
      description: '나트륨 양이온(Na⁺)과 수산화 음이온(OH⁻) 사이의 정전기적 인력으로 결합합니다.',
      atoms: [
        { id: 'na', element: 'Na', name: '나트륨 (Na⁺)', color: '#A855F7', radius: 32, x: -50, y: 0, z: 0 },
        { id: 'o', element: 'O', name: '산소 (O)', color: '#EF4444', radius: 28, x: 10, y: 0, z: 0 },
        { id: 'h', element: 'H', name: '수소 (H)', color: '#E0F2FE', radius: 18, x: 52, y: 0, z: 0 },
      ],
      bonds: [
        { from: 'na', to: 'o', order: 1 },
        { from: 'o', to: 'h', order: 1 },
      ],
    },
  },
  {
    id: 'H2O',
    name: '물 (순수한 물)',
    englishName: 'Water',
    formula: 'H2O',
    formulaDisplay: 'H₂O',
    category: 'neutral',
    state: 'liquid',
    color: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    liquidColor: 'rgba(59, 130, 246, 0.25)',
    glowColor: '#3b82f6',
    ph: 7.0,
    atomicOrMolarMass: 18.015,
    stateSymbol: '(l)',
    description: '생명체의 기본이 되는 물질이자 중성(pH 7) 액체. 산소 1개와 수소 2개가 104.5°로 굽은 구조입니다.',
    funFact: '물은 비열이 매우 크고 고체(얼음)가 액체(물)보다 부피가 커서 얼음이 물 위에 뜹니다!',
    hazard: '무해 (생명 필수 물질)',
    moleculeModel: {
      name: 'Water',
      koreanName: '물 분자 (H₂O)',
      formula: 'H₂O',
      bondType: '공유 결합',
      bondAngle: '104.5° (굽은형)',
      geometry: '굽은형 (V자 모양)',
      description: '산소의 비공유 전자쌍 2개 때문에 결합각이 104.5°로 굽어 있어 강한 극성을 띱니다.',
      atoms: [
        { id: 'o', element: 'O', name: '산소 (O)', color: '#EF4444', radius: 32, x: 0, y: -15, z: 0 },
        { id: 'h1', element: 'H', name: '수소 (H)', color: '#E0F2FE', radius: 22, x: -44, y: 25, z: 0 },
        { id: 'h2', element: 'H', name: '수소 (H)', color: '#E0F2FE', radius: 22, x: 44, y: 25, z: 0 },
      ],
      bonds: [
        { from: 'o', to: 'h1', order: 1 },
        { from: 'o', to: 'h2', order: 1 },
      ],
    },
  },
  {
    id: 'NaCl',
    name: '염화나트륨 (식염/소금)',
    englishName: 'Sodium Chloride',
    formula: 'NaCl',
    formulaDisplay: 'NaCl',
    category: 'salt',
    state: 'solid',
    color: 'bg-slate-200/20 text-slate-200 border-slate-400/40',
    liquidColor: 'rgba(226, 232, 240, 0.2)',
    glowColor: '#e2e8f0',
    ph: 7.0,
    atomicOrMolarMass: 58.44,
    stateSymbol: '(s)',
    description: '나트륨(Na⁺)과 염화(Cl⁻) 이온이 1:1로 결합한 전형적인 이온 결합 물질이자 정육면체 결정.',
    funFact: '물에 녹이면 양이온과 음이온으로 나누어져 전기를 잘 통하는 전해질 용액이 됩니다.',
    hazard: '무해 (과다섭취 주의)',
    moleculeModel: {
      name: 'Sodium Chloride',
      koreanName: '염화나트륨 이온 결정 (NaCl)',
      formula: 'NaCl',
      bondType: '이온 결합',
      geometry: '면심 입방 격자 (FCC)',
      description: 'Na⁺ 양이온과 Cl⁻ 음이온이 3차원 바둑판 모양으로 빽빽하게 배열된 결정 구조입니다.',
      atoms: [
        { id: 'na1', element: 'Na', name: '나트륨 (Na⁺)', color: '#A855F7', radius: 24, x: -40, y: -40, z: -40 },
        { id: 'cl1', element: 'Cl', name: '염소 (Cl⁻)', color: '#10B981', radius: 30, x: 40, y: -40, z: -40 },
        { id: 'cl2', element: 'Cl', name: '염소 (Cl⁻)', color: '#10B981', radius: 30, x: -40, y: 40, z: -40 },
        { id: 'na2', element: 'Na', name: '나트륨 (Na⁺)', color: '#A855F7', radius: 24, x: 40, y: 40, z: -40 },
        { id: 'cl3', element: 'Cl', name: '염소 (Cl⁻)', color: '#10B981', radius: 30, x: -40, y: -40, z: 40 },
        { id: 'na3', element: 'Na', name: '나트륨 (Na⁺)', color: '#A855F7', radius: 24, x: 40, y: -40, z: 40 },
        { id: 'na4', element: 'Na', name: '나트륨 (Na⁺)', color: '#A855F7', radius: 24, x: -40, y: 40, z: 40 },
        { id: 'cl4', element: 'Cl', name: '염소 (Cl⁻)', color: '#10B981', radius: 30, x: 40, y: 40, z: 40 },
      ],
      bonds: [
        { from: 'na1', to: 'cl1', order: 1 },
        { from: 'na1', to: 'cl2', order: 1 },
        { from: 'na1', to: 'cl3', order: 1 },
        { from: 'na2', to: 'cl1', order: 1 },
        { from: 'na2', to: 'cl2', order: 1 },
        { from: 'na2', to: 'cl4', order: 1 },
        { from: 'na3', to: 'cl1', order: 1 },
        { from: 'na3', to: 'cl3', order: 1 },
        { from: 'na3', to: 'cl4', order: 1 },
        { from: 'na4', to: 'cl2', order: 1 },
        { from: 'na4', to: 'cl3', order: 1 },
        { from: 'na4', to: 'cl4', order: 1 },
      ],
    },
  },
  {
    id: 'CO2',
    name: '이산화탄소',
    englishName: 'Carbon Dioxide',
    formula: 'CO2',
    formulaDisplay: 'CO₂',
    category: 'gas',
    state: 'gas',
    color: 'bg-zinc-500/20 text-zinc-300 border-zinc-500/40',
    liquidColor: 'rgba(161, 161, 170, 0.2)',
    glowColor: '#a1a1aa',
    ph: 5.6,
    atomicOrMolarMass: 44.01,
    stateSymbol: '(g)',
    description: '공기보다 무겁고 불을 끄는 성질이 있는 온실 기체. 탄산음료의 톡 쏘는 기포입니다.',
    funFact: '석회수에 통과시키면 탄산칼슘 앙금이 생겨 뿌옇게 흐려집니다!',
    hazard: '밀폐 공간 질식 주의',
    moleculeModel: {
      name: 'Carbon Dioxide',
      koreanName: '이산화탄소 분자 (CO₂)',
      formula: 'CO₂',
      bondType: '공유 결합',
      bondAngle: '180° (직선형)',
      geometry: '직선형 무극성 분자',
      description: '중심 탄소 원자가 양쪽 산소와 각각 이중 결합을 하여 180° 직선형을 이룹니다.',
      atoms: [
        { id: 'c', element: 'C', name: '탄소 (C)', color: '#374151', radius: 28, x: 0, y: 0, z: 0 },
        { id: 'o1', element: 'O', name: '산소 (O)', color: '#EF4444', radius: 28, x: -55, y: 0, z: 0 },
        { id: 'o2', element: 'O', name: '산소 (O)', color: '#EF4444', radius: 28, x: 55, y: 0, z: 0 },
      ],
      bonds: [
        { from: 'c', to: 'o1', order: 2 },
        { from: 'c', to: 'o2', order: 2 },
      ],
    },
  },
  {
    id: 'C',
    name: '탄소 (숯/흑연)',
    englishName: 'Carbon',
    formula: 'C',
    formulaDisplay: 'C',
    category: 'metal',
    state: 'solid',
    color: 'bg-neutral-600/30 text-neutral-200 border-neutral-500/40',
    liquidColor: 'rgba(64, 64, 64, 0.3)',
    glowColor: '#737373',
    ph: 7.0,
    atomicOrMolarMass: 12.011,
    stateSymbol: '(s)',
    description: '생명체를 이루는 유기물의 중심 원소. 흑연, 다이아몬드, 숯 등이 모두 탄소의 동소체입니다.',
    funFact: '산소와 만나 불타면 열과 빛을 내며 이산화탄소(CO₂) 기체가 됩니다.',
    hazard: '무해 고체',
  },
  {
    id: 'CaCO3',
    name: '탄산칼슘 (조개껍질/석회석)',
    englishName: 'Calcium Carbonate',
    formula: 'CaCO3',
    formulaDisplay: 'CaCO₃',
    category: 'salt',
    state: 'solid',
    color: 'bg-stone-300/20 text-stone-200 border-stone-400/40',
    liquidColor: 'rgba(231, 229, 228, 0.3)',
    glowColor: '#e7e5e4',
    ph: 9.0,
    atomicOrMolarMass: 100.09,
    stateSymbol: '(s)',
    description: '분필, 대리석, 달걀 껍데기, 조개껍데기의 주성분. 묽은 염산과 반응하면 CO₂ 기체가 부글부글 발생합니다.',
    funFact: '석회동굴의 종유석과 석순도 수만 년에 걸쳐 만들어진 탄산칼슘입니다!',
    hazard: '무해 분말',
  },
  {
    id: 'CaCl2',
    name: '염화칼슘',
    englishName: 'Calcium Chloride',
    formula: 'CaCl2',
    formulaDisplay: 'CaCl₂',
    category: 'salt',
    state: 'solid',
    color: 'bg-yellow-200/20 text-yellow-200 border-yellow-400/40',
    liquidColor: 'rgba(254, 240, 138, 0.2)',
    glowColor: '#fef08a',
    ph: 7.0,
    atomicOrMolarMass: 110.98,
    stateSymbol: '(s)',
    description: '수분을 흡수하는 조해성이 뛰어난 염. 겨울철 도로의 눈을 녹이는 제설제로 널리 쓰입니다.',
    funFact: '물에 녹을 때 많은 열(용해열)을 방출하여 눈을 빠르게 녹입니다.',
    hazard: '피부 건조 유발',
  },
  {
    id: 'Fe',
    name: '철 (못/철가루)',
    englishName: 'Iron',
    formula: 'Fe',
    formulaDisplay: 'Fe',
    category: 'metal',
    state: 'solid',
    color: 'bg-slate-500/20 text-slate-300 border-slate-500/40',
    liquidColor: 'rgba(100, 116, 139, 0.3)',
    glowColor: '#64748b',
    ph: 7.0,
    atomicOrMolarMass: 55.845,
    stateSymbol: '(s)',
    description: '산업의 쌀이라 불리는 가장 대표적인 금속. 자석에 달라붙으며 구리보다 반응성이 큽니다.',
    funFact: '푸른색 황산구리 용액에 철 못을 넣으면 붉은색 구리가 표면에 석출됩니다!',
    hazard: '무해',
  },
  {
    id: 'CuSO4',
    name: '황산구리 수용액',
    englishName: 'Copper(II) Sulfate',
    formula: 'CuSO4',
    formulaDisplay: 'CuSO₄',
    category: 'compound',
    state: 'aqueous',
    color: 'bg-sky-600/30 text-sky-200 border-sky-500/50',
    liquidColor: 'rgba(2, 132, 199, 0.65)',
    glowColor: '#0284c7',
    ph: 4.5,
    atomicOrMolarMass: 159.61,
    stateSymbol: '(aq)',
    description: '구리 이온(Cu²⁺) 때문에 아름다운 푸른색을 띠는 수용액입니다.',
    funFact: '철(Fe)을 넣으면 철이 녹고 붉은 구리가 전기도금처럼 석출됩니다!',
    hazard: '삼킴 금지, 유독성',
  },
  {
    id: 'Cu',
    name: '구리 금속',
    englishName: 'Copper',
    formula: 'Cu',
    formulaDisplay: 'Cu',
    category: 'metal',
    state: 'solid',
    color: 'bg-amber-600/30 text-amber-300 border-amber-500/50',
    liquidColor: 'rgba(217, 119, 6, 0.4)',
    glowColor: '#d97706',
    ph: 7.0,
    atomicOrMolarMass: 63.546,
    stateSymbol: '(s)',
    description: '붉은 갈색을 띠는 금속으로 전기와 열을 매우 잘 전달합니다.',
    funFact: '전선, 10원짜리 동전의 주재료로 쓰입니다.',
    hazard: '무해',
  },
  {
    id: 'FeSO4',
    name: '황산철 수용액',
    englishName: 'Iron(II) Sulfate',
    formula: 'FeSO4',
    formulaDisplay: 'FeSO₄',
    category: 'compound',
    state: 'aqueous',
    color: 'bg-emerald-700/20 text-emerald-300 border-emerald-600/40',
    liquidColor: 'rgba(16, 185, 129, 0.4)',
    glowColor: '#10b981',
    ph: 5.0,
    atomicOrMolarMass: 151.91,
    stateSymbol: '(aq)',
    description: '철 이온(Fe²⁺)이 녹아있는 옅은 연녹색 수용액입니다.',
    funFact: '황산구리와 철의 치환 반응 결과 생성됩니다.',
    hazard: '무해',
  },
  // Indicators
  {
    id: 'ind_universal',
    name: '만능 지시약 (Rainbow Indicator)',
    englishName: 'Universal Indicator',
    formula: 'Indicator',
    formulaDisplay: '만능지시약',
    category: 'indicator',
    state: 'liquid',
    color: 'bg-gradient-to-r from-red-500/30 via-green-500/30 to-purple-500/30 text-emerald-200 border-emerald-400/50',
    liquidColor: 'rgba(34, 197, 94, 0.5)',
    glowColor: '#22c55e',
    ph: 7.0,
    atomicOrMolarMass: 0,
    stateSymbol: '(l)',
    isIndicator: true,
    indicatorType: 'universal',
    description: '용액의 pH에 따라 빨강(강산) → 노랑(약산) → 초록(중성) → 파랑(약염기) → 보라(강염기)로 무지개색 변화를 보여줍니다.',
    funFact: '여러 가지 지시약을 혼합하여 넓은 pH 범위를 한 번에 알아낼 수 있도록 만든 마법의 시약입니다!',
    hazard: '식용 금지',
  },
  {
    id: 'ind_btb',
    name: 'BTB 용액 (브롬티몰블루)',
    englishName: 'BTB Solution',
    formula: 'BTB',
    formulaDisplay: 'BTB',
    category: 'indicator',
    state: 'liquid',
    color: 'bg-teal-500/20 text-teal-300 border-teal-500/40',
    liquidColor: 'rgba(20, 184, 166, 0.4)',
    glowColor: '#14b8a6',
    ph: 7.0,
    atomicOrMolarMass: 0,
    stateSymbol: '(l)',
    isIndicator: true,
    indicatorType: 'btb',
    description: '산성에서는 노란색(Yellow), 중성에서는 초록색(Green), 염기성에서는 파란색(Blue)으로 명확히 변합니다.',
    funFact: '빨대로 날숨(이산화탄소)을 불어넣으면 물이 산성화되어 초록색에서 노란색으로 변합니다!',
    hazard: '식용 금지',
  },
  {
    id: 'ind_phenolphthalein',
    name: '페놀프탈레인 용액',
    englishName: 'Phenolphthalein',
    formula: 'Phenol',
    formulaDisplay: '페놀프탈레인',
    category: 'indicator',
    state: 'liquid',
    color: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/40',
    liquidColor: 'rgba(217, 70, 239, 0.3)',
    glowColor: '#d946ef',
    ph: 7.0,
    atomicOrMolarMass: 0,
    stateSymbol: '(l)',
    isIndicator: true,
    indicatorType: 'phenolphthalein',
    description: '산성과 중성에서는 무색투명하지만, 염기성(pH > 8.2)을 만나면 즉시 선명한 붉은 핫핑크색으로 변합니다!',
    funFact: '비밀 편지를 쓸 때 페놀프탈레인으로 글씨를 쓰고, 비눗물(염기성)을 뿌리면 붉은 글씨가 마법처럼 나타납니다.',
    hazard: '식용 금지',
  },
  {
    id: 'ind_litmus_red',
    name: '붉은색 리트머스 종이',
    englishName: 'Red Litmus',
    formula: 'Litmus(R)',
    formulaDisplay: '붉은 리트머스',
    category: 'indicator',
    state: 'solid',
    color: 'bg-red-500/20 text-red-300 border-red-500/40',
    liquidColor: 'rgba(239, 68, 68, 0.3)',
    glowColor: '#ef4444',
    ph: 7.0,
    atomicOrMolarMass: 0,
    stateSymbol: '(s)',
    isIndicator: true,
    indicatorType: 'litmus_red',
    description: '염기성 용액(NaOH 등)에 닿으면 푸른색으로 변하여 염기성을 확인하는 리트머스 종이입니다.',
    funFact: '지의류(이끼의 일종)에서 추출한 천연 염료로 만들어진 지시약입니다.',
  },
  {
    id: 'ind_litmus_blue',
    name: '푸른색 리트머스 종이',
    englishName: 'Blue Litmus',
    formula: 'Litmus(B)',
    formulaDisplay: '푸른 리트머스',
    category: 'indicator',
    state: 'solid',
    color: 'bg-blue-600/20 text-blue-300 border-blue-500/40',
    liquidColor: 'rgba(37, 99, 235, 0.3)',
    glowColor: '#2563eb',
    ph: 7.0,
    atomicOrMolarMass: 0,
    stateSymbol: '(s)',
    isIndicator: true,
    indicatorType: 'litmus_blue',
    description: '산성 용액(HCl 등)에 닿으면 붉은색으로 변하여 산성을 판별하는 리트머스 종이입니다.',
    funFact: '산(Acid)의 글자 붉은색과 연상하면 쉽게 외울 수 있습니다 (산붉, 염푸)!',
  },
];

export const REACTIONS: ChemicalReaction[] = [
  {
    id: 'rx_h2_o2',
    name: '물의 합성 (수소의 폭발적 연소)',
    title: '수소와 산소의 결합: 생명의 물(H₂O) 생성!',
    condition: 'heat',
    reactants: { H2: 2, O2: 1 },
    products: { H2O: 2 },
    balancedEquation: '2H₂ (g) + O₂ (g) ➔ 2H₂O (l) + 572 kJ',
    reactionType: '연소(산화) 반응',
    heatChange: 'exothermic',
    temperatureRise: 65,
    visualEffect: 'explosion',
    soundType: 'explosion',
    curriculumPoint: '중3 화학 반응의 규칙성 (기체 반응 법칙 / 질량 보존 법칙)',
    explanation:
      '수소 기체 2부피와 산소 기체 1부피가 열(점화)을 받아 격렬하게 반응하며 빛과 열을 방출하고 수증기/물이 생성됩니다. 수소와 산소의 부피비는 항상 정확히 2:1로 반응합니다!',
  },
  {
    id: 'rx_na_cl2',
    name: '소금의 생성 (나트륨과 염소의 화합)',
    title: '금속과 유독 기체의 만남: 맛있는 소금(NaCl) 탄생!',
    condition: 'heat',
    reactants: { Na: 2, Cl2: 1 },
    products: { NaCl: 2 },
    balancedEquation: '2Na (s) + Cl₂ (g) ➔ 2NaCl (s) + 열',
    reactionType: '연소(산화) 반응',
    heatChange: 'exothermic',
    temperatureRise: 55,
    visualEffect: 'sparkles',
    soundType: 'explosion',
    curriculumPoint: '중2 물질의 특성 & 중3 이온 결합의 형성',
    explanation:
      '위험한 금속 나트륨(Na)과 독성이 강한 염소 기체(Cl₂)가 반응하여, 나트륨이 전자를 잃고 염소가 전자를 얻어 인체에 필수적인 안전한 소금 결정(NaCl)으로 완전히 새로운 성질을 갖게 됩니다!',
  },
  {
    id: 'rx_neutralization_hcl_naoh',
    name: '산과 염기의 중화 반응 (염산 + 수산화나트륨)',
    title: '산과 염기의 만남: 중화열 발생 및 소금물 생성!',
    condition: 'stir',
    reactants: { HCl: 1, NaOH: 1 },
    products: { NaCl: 1, H2O: 1 },
    balancedEquation: 'HCl (aq) + NaOH (aq) ➔ NaCl (aq) + H₂O (l) + 중화열',
    reactionType: '중화 반응',
    heatChange: 'exothermic',
    temperatureRise: 18,
    visualEffect: 'bubbles',
    soundType: 'fizz',
    curriculumPoint: '초6 산과 염기 & 중3 중화 반응과 pH',
    explanation:
      '염산의 수소 이온(H⁺)과 수산화나트륨의 수산화 이온(OH⁻)이 1:1로 결합하여 중성인 물(H₂O)이 되고, 나트륨 이온과 염화 이온이 남아 염화나트륨(소금) 수용액이 되며 온도가 상승(중화열)합니다.',
  },
  {
    id: 'rx_electrolysis_water',
    name: '물의 전기 분해',
    title: '전기를 통과시켜 물을 수소와 산소로 분해하기!',
    condition: 'electricity',
    reactants: { H2O: 2 },
    products: { H2: 2, O2: 1 },
    balancedEquation: '2H₂O (l) ➔ 2H₂ (g) ↑ + O₂ (g) ↑',
    reactionType: '전기 분해 반응',
    heatChange: 'endothermic',
    temperatureRise: -2,
    visualEffect: 'bubbles',
    soundType: 'spark',
    curriculumPoint: '중2 물질의 구성 & 전기 분해 원리',
    explanation:
      '순수한 물에 전기를 흘려주면 (-)극에서는 수소 기체(H₂)가 2부피, (+)극에서는 산소 기체(O₂)가 1부피 발생하여 물이 기본 원소로 분해됩니다. 이를 통해 물이 원소가 아닌 화합물임을 증명합니다!',
  },
  {
    id: 'rx_na_water',
    name: '나트륨의 물 반응',
    title: '나트륨 금속이 물과 격렬하게 반응하여 수소 기체 방출!',
    condition: 'auto',
    reactants: { Na: 2, H2O: 2 },
    products: { NaOH: 2, H2: 1 },
    balancedEquation: '2Na (s) + 2H₂O (l) ➔ 2NaOH (aq) + H₂ (g) ↑ + 열',
    reactionType: '기체 발생 반응',
    heatChange: 'exothermic',
    temperatureRise: 42,
    visualEffect: 'explosion',
    soundType: 'fizz',
    curriculumPoint: '중2 알칼리 금속의 반응성 & 수용액의 액성',
    explanation:
      '알칼리 금속인 나트륨이 물과 만나면 격렬하게 열과 수소 기체를 뿜어내며, 생성된 용액은 수산화나트륨(NaOH)이 되어 강한 염기성을 띱니다. 지시약을 넣으면 즉시 붉은색/파란색으로 변합니다!',
  },
  {
    id: 'rx_caco3_hcl',
    name: '탄산칼슘과 염산의 반응 (조개껍질 녹이기)',
    title: '달걀 껍데기와 염산이 만나 이산화탄소 거품 폭발!',
    condition: 'stir',
    reactants: { CaCO3: 1, HCl: 2 },
    products: { CaCl2: 1, H2O: 1, CO2: 1 },
    balancedEquation: 'CaCO₃ (s) + 2HCl (aq) ➔ CaCl₂ (aq) + H₂O (l) + CO₂ (g) ↑',
    reactionType: '기체 발생 반응',
    heatChange: 'exothermic',
    temperatureRise: 12,
    visualEffect: 'bubbles',
    soundType: 'fizz',
    curriculumPoint: '초6 여러 가지 기체 & 산의 성질',
    explanation:
      '탄산칼슘(달걀 껍질, 대리석, 조개껍데기)에 산성 물질이 닿으면 이산화탄소(CO₂) 기체가 보글보글 거품을 일으키며 녹아내립니다. 산성비가 대리석 조각상을 부식시키는 원리이기도 합니다.',
  },
  {
    id: 'rx_c_o2',
    name: '탄소(숯)의 연소',
    title: '숯이 산소와 결합하여 이산화탄소와 뜨거운 열 방출!',
    condition: 'heat',
    reactants: { C: 1, O2: 1 },
    products: { CO2: 1 },
    balancedEquation: 'C (s) + O₂ (g) ➔ CO₂ (g) + 열',
    reactionType: '연소(산화) 반응',
    heatChange: 'exothermic',
    temperatureRise: 50,
    visualEffect: 'sparkles',
    soundType: 'explosion',
    curriculumPoint: '중3 화학 반응과 에너지 (발열 반응)',
    explanation:
      '고체 탄소가 산소 기체와 반응하여 이산화탄소 기체가 되면서 강력한 열에너지를 방출합니다. 캠핑장에서 숯불 바비큐를 할 때 일어나는 친숙한 반응입니다.',
  },
  {
    id: 'rx_fe_cuso4',
    name: '철과 황산구리의 금속 치환 반응',
    title: '철 못에 붉은 구리가 전기도금처럼 코팅되는 마법!',
    condition: 'stir',
    reactants: { Fe: 1, CuSO4: 1 },
    products: { FeSO4: 1, Cu: 1 },
    balancedEquation: 'Fe (s) + CuSO₄ (aq) ➔ FeSO₄ (aq) + Cu (s)',
    reactionType: '금속 치환 반응',
    heatChange: 'neutral',
    temperatureRise: 5,
    visualEffect: 'sparkles',
    soundType: 'success',
    curriculumPoint: '중3 금속의 반응성 순서 (Fe > Cu)',
    explanation:
      '철(Fe)이 구리(Cu)보다 전자를 잃고 양이온이 되려는 경향(반응성)이 크기 때문에, 철이 녹아 푸른 용액이 연녹색으로 옅어지고 철 표면에 붉은 구리 금속이 석출됩니다!',
  },
];

export const QUESTS: Quest[] = [
  {
    id: 'q1',
    title: '💧 생명의 물(H₂O) 합성하기',
    category: '기초',
    targetReactionId: 'rx_h2_o2',
    description: '수소 기체(H₂) 2개와 산소 기체(O₂) 1개를 비커에 넣고 [🔥 열 가하기]를 눌러 물을 만드세요!',
    hint: '수소와 산소의 비율을 2:1로 맞춘 뒤 하단의 [🔥 가열 반응] 버튼을 클릭하세요.',
    rewardStars: 3,
    badge: '물 분자 마스터',
  },
  {
    id: 'q2',
    title: '🧂 맛있는 소금(NaCl) 만들기',
    category: '기초',
    targetReactionId: 'rx_na_cl2',
    description: '위험한 나트륨 금속(Na) 2개와 염소 기체(Cl₂) 1개를 조합하여 소금을 합성하세요!',
    hint: '나트륨 2개와 염소 1개를 넣고 [🔥 열 가하기]를 누르면 눈부신 섬광과 함께 소금이 탄생합니다.',
    rewardStars: 3,
    badge: '소금 연금술사',
  },
  {
    id: 'q3',
    title: '🌈 산과 염기의 중화 작전',
    category: '산과 염기',
    targetReactionId: 'rx_neutralization_hcl_naoh',
    description: '강산인 염산(HCl)과 강염기인 수산화나트륨(NaOH)을 1:1로 섞어 중성 소금물을 만드세요!',
    hint: '만능 지시약이나 BTB를 넣고 HCl과 NaOH를 1:1로 반응시키면 초록색 중성이 됩니다.',
    rewardStars: 4,
    badge: '중화 반응 사령관',
  },
  {
    id: 'q4',
    title: '⚡ 물을 전기 분해하여 기체 얻기',
    category: '에너지',
    targetReactionId: 'rx_electrolysis_water',
    description: '물(H₂O)을 비커에 담고 [⚡ 전기 분해] 버튼을 눌러 수소와 산소로 쪼개보세요!',
    hint: '물 2개를 비커에 넣은 뒤 하단의 [⚡ 전기 분해] 버튼을 누르세요.',
    rewardStars: 4,
    badge: '전기 화학자',
  },
  {
    id: 'q5',
    title: '🫧 조개껍질 녹여 탄산 기포 만들기',
    category: '산과 염기',
    targetReactionId: 'rx_caco3_hcl',
    description: '탄산칼슘(CaCO₃)에 묽은 염산(HCl) 2개를 넣어 이산화탄소(CO₂) 기포를 발생시키세요!',
    hint: 'CaCO₃ 1개 + HCl 2개를 넣고 [🧪 자연 반응/섞기]를 누르세요.',
    rewardStars: 4,
    badge: '기체 탐험가',
  },
  {
    id: 'q6',
    title: '💥 나트륨의 격렬한 물 반응',
    category: '에너지',
    targetReactionId: 'rx_na_water',
    description: '나트륨(Na)과 물(H₂O)을 섞어 수소 기체와 강염기 수산화나트륨(NaOH)을 만들어보세요!',
    hint: 'Na 2개와 H₂O 2개를 넣으면 자발적으로 격렬한 반응이 일어납니다.',
    rewardStars: 5,
    badge: '원소 폭발 마스터',
  },
  {
    id: 'q7',
    title: '🎨 무지개 pH 스펙트럼 탐색',
    category: '산과 염기',
    description: '만능 지시약을 넣은 상태에서 HCl(산성)과 NaOH(염기성)의 양을 조절하여 빨강/초록/보라색을 모두 관찰해보세요!',
    hint: 'pH 탐색 가이드 바를 보며 지시약과 산/염기를 조금씩 추가해 보세요.',
    rewardStars: 5,
    badge: 'pH 레인보우 아티스트',
  },
];

// Helper to compute beaker dynamic liquid color & pH
export function calculateLiquidState(substanceMap: { [id: string]: number }) {
  // Count acid vs base vs neutral
  let totalH = 0;
  let totalOH = 0;
  let hasIndicator: string | null = null;
  let totalUnits = 0;

  for (const [id, count] of Object.entries(substanceMap)) {
    if (count <= 0) continue;
    totalUnits += count;
    if (id === 'HCl') totalH += count * 1.0;
    if (id === 'NaOH') totalOH += count * 1.0;
    if (id.startsWith('ind_')) hasIndicator = id;
    if (id === 'CuSO4') {
      // Distinct copper blue
    }
  }

  // Base pH calculation
  let currentPh = 7.0;
  if (totalH > totalOH) {
    const diff = totalH - totalOH;
    currentPh = Math.max(0.5, 7.0 - Math.log10(1 + diff * 3) * 3);
  } else if (totalOH > totalH) {
    const diff = totalOH - totalH;
    currentPh = Math.min(14.0, 7.0 + Math.log10(1 + diff * 3) * 3);
  } else {
    currentPh = 7.0;
  }

  currentPh = Number(currentPh.toFixed(1));

  // Determine liquid base color
  let liquidColor = 'rgba(59, 130, 246, 0.2)'; // default subtle blue water
  let indicatorColorName = '무색 / 옅은 푸른색';

  if (substanceMap['CuSO4'] && substanceMap['CuSO4'] > 0) {
    liquidColor = 'rgba(2, 132, 199, 0.7)';
    indicatorColorName = '황산구리 청록색';
  } else if (substanceMap['FeSO4'] && substanceMap['FeSO4'] > 0) {
    liquidColor = 'rgba(16, 185, 129, 0.45)';
    indicatorColorName = '황산철 연녹색';
  } else if (hasIndicator === 'ind_universal') {
    // Universal indicator color based on pH
    if (currentPh <= 3.0) {
      liquidColor = 'rgba(239, 68, 68, 0.85)'; // Red (pH 1-3)
      indicatorColorName = '강산성 붉은색';
    } else if (currentPh <= 5.5) {
      liquidColor = 'rgba(249, 115, 22, 0.85)'; // Orange (pH 4-5)
      indicatorColorName = '약산성 주황색';
    } else if (currentPh <= 6.5) {
      liquidColor = 'rgba(234, 179, 8, 0.85)'; // Yellow (pH 6)
      indicatorColorName = '미산성 노란색';
    } else if (currentPh >= 6.6 && currentPh <= 7.4) {
      liquidColor = 'rgba(34, 197, 94, 0.85)'; // Green (pH 7 중성)
      indicatorColorName = '중성 초록색';
    } else if (currentPh <= 9.0) {
      liquidColor = 'rgba(6, 182, 212, 0.85)'; // Cyan/Blue (pH 8-9)
      indicatorColorName = '약염기성 청록색';
    } else if (currentPh <= 11.5) {
      liquidColor = 'rgba(59, 130, 246, 0.85)'; // Deep Blue (pH 10-11)
      indicatorColorName = '염기성 파란색';
    } else {
      liquidColor = 'rgba(147, 51, 234, 0.9)'; // Purple / Violet (pH 12-14)
      indicatorColorName = '강염기성 보라색';
    }
  } else if (hasIndicator === 'ind_btb') {
    if (currentPh < 6.0) {
      liquidColor = 'rgba(234, 179, 8, 0.85)'; // Yellow
      indicatorColorName = '산성 노란색';
    } else if (currentPh > 7.6) {
      liquidColor = 'rgba(37, 99, 235, 0.85)'; // Blue
      indicatorColorName = '염기성 파란색';
    } else {
      liquidColor = 'rgba(34, 197, 94, 0.85)'; // Green
      indicatorColorName = '중성 초록색';
    }
  } else if (hasIndicator === 'ind_phenolphthalein') {
    if (currentPh >= 8.3) {
      liquidColor = 'rgba(236, 72, 153, 0.85)'; // Hot pink
      indicatorColorName = '염기성 선명한 분홍/붉은색';
    } else {
      liquidColor = 'rgba(241, 245, 249, 0.25)'; // Colorless
      indicatorColorName = '산성/중성 무색투명';
    }
  } else if (hasIndicator === 'ind_litmus_red') {
    if (currentPh > 8.0) {
      liquidColor = 'rgba(59, 130, 246, 0.7)';
      indicatorColorName = '염기성 푸른색 반응';
    } else {
      liquidColor = 'rgba(239, 68, 68, 0.5)';
      indicatorColorName = '붉은색 유지';
    }
  } else if (hasIndicator === 'ind_litmus_blue') {
    if (currentPh < 6.0) {
      liquidColor = 'rgba(239, 68, 68, 0.7)';
      indicatorColorName = '산성 붉은색 반응';
    } else {
      liquidColor = 'rgba(37, 99, 235, 0.5)';
      indicatorColorName = '푸른색 유지';
    }
  } else {
    // No indicator, simple tint if acid/base
    if (currentPh < 4.0) {
      liquidColor = 'rgba(245, 158, 11, 0.25)';
    } else if (currentPh > 10.0) {
      liquidColor = 'rgba(99, 102, 241, 0.25)';
    }
  }

  return {
    ph: currentPh,
    liquidColor,
    indicatorColorName,
    hasIndicator: !!hasIndicator,
    indicatorType: hasIndicator,
    totalUnits,
  };
}
