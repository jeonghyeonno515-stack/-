export type SubstanceCategory =
  | 'gas'
  | 'metal'
  | 'acid'
  | 'base'
  | 'neutral'
  | 'salt'
  | 'compound'
  | 'indicator';

export type PhysicalState = 'gas' | 'liquid' | 'solid' | 'aqueous';

export type ReactionCondition = 'heat' | 'electricity' | 'stir' | 'auto';

export interface Atom3D {
  id: string;
  element: string;
  name: string;
  color: string;
  radius: number;
  x: number;
  y: number;
  z: number;
}

export interface Bond3D {
  from: string;
  to: string;
  order: 1 | 2 | 3;
}

export interface Molecule3DModel {
  name: string;
  koreanName: string;
  formula: string;
  bondType: '공유 결합' | '이온 결합' | '금속 결합' | '단일 원소';
  bondAngle?: string;
  geometry: string;
  atoms: Atom3D[];
  bonds: Bond3D[];
  description: string;
}

export interface Substance {
  id: string;
  name: string;
  englishName: string;
  formula: string;
  formulaDisplay: string;
  category: SubstanceCategory;
  state: PhysicalState;
  color: string; // Tailwind-friendly or Hex for UI badge
  liquidColor: string; // RGBA or Hex for beaker liquid
  glowColor: string;
  ph: number; // typical pH of 1M aqueous solution or inherent pH
  isIndicator?: boolean;
  indicatorType?: 'litmus_red' | 'litmus_blue' | 'phenolphthalein' | 'btb' | 'universal';
  description: string;
  funFact: string;
  hazard?: string;
  atomicOrMolarMass: number;
  stateSymbol: '(g)' | '(l)' | '(s)' | '(aq)';
  moleculeModel?: Molecule3DModel;
}

export interface BeakerSubstance {
  substanceId: string;
  amount: number; // units / drops / moles
  addedAt: number;
}

export interface ChemicalReaction {
  id: string;
  name: string;
  reactants: { [substanceId: string]: number }; // stoichiometry: id -> ratio
  condition: ReactionCondition;
  products: { [substanceId: string]: number }; // stoichiometry
  balancedEquation: string;
  reactionType:
    | '연소(산화) 반응'
    | '중화 반응'
    | '전기 분해 반응'
    | '기체 발생 반응'
    | '침전 생성 반응'
    | '금속 치환 반응';
  heatChange: 'exothermic' | 'endothermic' | 'neutral';
  temperatureRise: number; // °C increase
  visualEffect: 'explosion' | 'sparkles' | 'bubbles' | 'steam' | 'precipitate' | 'fizz';
  soundType: 'explosion' | 'spark' | 'bubbles' | 'fizz' | 'success';
  title: string;
  explanation: string;
  curriculumPoint: string; // e.g. "중3 화학 반응의 규칙성", "초6 산과 염기"
}

export interface Quest {
  id: string;
  title: string;
  category: '기초' | '산과 염기' | '에너지' | '고급';
  targetReactionId?: string;
  targetSubstanceId?: string;
  targetPhRange?: [number, number];
  description: string;
  hint: string;
  rewardStars: number;
  badge: string;
}
