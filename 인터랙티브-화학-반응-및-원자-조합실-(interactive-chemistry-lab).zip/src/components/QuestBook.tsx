import React, { useState } from 'react';
import { Quest, ChemicalReaction, Substance } from '../types';
import { QUESTS, REACTIONS, SUBSTANCES } from '../utils/chemistryData';
import {
  Trophy,
  Star,
  CheckCircle,
  Circle,
  HelpCircle,
  BookOpen,
  Award,
  Sparkles,
  ChevronRight,
  Eye,
} from 'lucide-react';
import { soundManager } from '../utils/audio';

interface QuestBookProps {
  completedQuestIds: string[];
  discoveredReactionIds: string[];
  onSelectQuest: (quest: Quest) => void;
  onInspectSubstance: (substance: Substance) => void;
  onClose: () => void;
}

export const QuestBook: React.FC<QuestBookProps> = ({
  completedQuestIds,
  discoveredReactionIds,
  onSelectQuest,
  onInspectSubstance,
  onClose,
}) => {
  const [tab, setTab] = useState<'quests' | 'encyclopedia'>('quests');

  const totalStars = completedQuestIds.reduce((sum, qId) => {
    const q = QUESTS.find((item) => item.id === qId);
    return sum + (q ? q.rewardStars : 0);
  }, 0);

  // Student Level Calculation
  const getStudentRank = (stars: number) => {
    if (stars >= 25) return { title: '👑 노벨 화학상 마스터', level: 5, color: 'text-amber-400' };
    if (stars >= 18) return { title: '🧪 수석 화학 연구원', level: 4, color: 'text-cyan-400' };
    if (stars >= 12) return { title: '⚡ 원소 마술사', level: 3, color: 'text-emerald-400' };
    if (stars >= 6) return { title: '🔬 견습 실험자', level: 2, color: 'text-blue-400' };
    return { title: '🌱 새싹 과학 꿈나무', level: 1, color: 'text-slate-300' };
  };

  const rank = getStudentRank(totalStars);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div
        id="quest-book-dialog"
        className="relative w-full max-w-2xl bg-slate-900 border border-cyan-500/40 rounded-2xl shadow-2xl p-5 text-slate-100 flex flex-col gap-4 max-h-[90vh] overflow-y-auto"
      >
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 font-black shadow-lg shadow-amber-500/20">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-bold ${rank.color}`}>{rank.title}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                  LV.{rank.level}
                </span>
              </div>
              <h2 className="text-base font-black text-slate-100 mt-0.5">
                화학 탐구 퀘스트 & 실험 도감 (Lab Quests)
              </h2>
            </div>
          </div>

          {/* Star Counter */}
          <div className="flex items-center gap-1.5 bg-amber-950/60 border border-amber-500/40 px-3 py-1.5 rounded-xl text-amber-300 shadow-inner">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400 animate-pulse" />
            <span className="font-mono font-black text-sm">{totalStars}</span>
            <span className="text-[10px] text-amber-400/80 font-bold">Stars</span>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => {
              soundManager.playClick();
              setTab('quests');
            }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === 'quests'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>탐구 퀘스트 목록 ({completedQuestIds.length}/{QUESTS.length})</span>
          </button>
          <button
            onClick={() => {
              soundManager.playClick();
              setTab('encyclopedia');
            }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === 'encyclopedia'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>발견한 반응 도감 ({discoveredReactionIds.length}/{REACTIONS.length})</span>
          </button>
        </div>

        {/* Quests View */}
        {tab === 'quests' && (
          <div className="flex flex-col gap-2.5 max-h-96 overflow-y-auto pr-1">
            {QUESTS.map((quest) => {
              const isDone = completedQuestIds.includes(quest.id);
              return (
                <div
                  key={quest.id}
                  id={`quest-item-${quest.id}`}
                  className={`flex flex-col gap-2 p-3.5 rounded-xl border transition-all ${
                    isDone
                      ? 'bg-emerald-950/20 border-emerald-500/40 shadow-sm'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {isDone ? (
                        <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-600 shrink-0" />
                      )}
                      <div>
                        <h4 className="text-xs font-bold text-slate-200">{quest.title}</h4>
                        <span className="text-[10px] text-cyan-400 font-medium">
                          분야: {quest.category} • 뱃지: {quest.badge}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded border border-slate-700 text-amber-300 text-xs font-mono font-bold">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>+{quest.rewardStars}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed pl-7">{quest.description}</p>

                  <div className="flex items-center justify-between pl-7 pt-1 border-t border-slate-800/60">
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <HelpCircle className="w-3.5 h-3.5 text-amber-400/80" />
                      <span>힌트: {quest.hint}</span>
                    </span>

                    {!isDone && (
                      <button
                        onClick={() => {
                          onSelectQuest(quest);
                          onClose();
                        }}
                        className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5 transition-colors"
                      >
                        <span>실험하러 가기</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Encyclopedia View */}
        {tab === 'encyclopedia' && (
          <div className="flex flex-col gap-2.5 max-h-96 overflow-y-auto pr-1">
            {REACTIONS.map((rx) => {
              const isDiscovered = discoveredReactionIds.includes(rx.id);
              const productSubstances = SUBSTANCES.filter((s) =>
                Object.keys(rx.products).includes(s.id)
              );

              return (
                <div
                  key={rx.id}
                  className={`flex flex-col gap-2 p-3.5 rounded-xl border transition-all ${
                    isDiscovered
                      ? 'bg-slate-950/80 border-cyan-500/30'
                      : 'bg-slate-950/40 border-slate-800/60 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-200">
                        {isDiscovered ? rx.name : '🔒 미발견 화학 반응'}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {rx.reactionType}
                      </span>
                    </div>
                    {isDiscovered && (
                      <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        <span>기록 완료</span>
                      </span>
                    )}
                  </div>

                  {isDiscovered ? (
                    <>
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-xs text-cyan-300 text-center font-bold">
                        {rx.balancedEquation}
                      </div>
                      <p className="text-xs text-slate-400">{rx.explanation}</p>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {productSubstances.map((ps) => (
                          <button
                            key={ps.id}
                            onClick={() => {
                              onInspectSubstance(ps);
                              onClose();
                            }}
                            className="flex items-center gap-1 text-[11px] bg-slate-800 hover:bg-slate-700 px-2 py-0.5 rounded text-cyan-300 border border-slate-700"
                          >
                            <Eye className="w-3 h-3" />
                            <span>{ps.formulaDisplay} ({ps.name}) 3D 구조</span>
                          </button>
                        ))}
                      </div>
                    </>
                  ) : (
                    <p className="text-xs text-slate-500 italic">
                      실험실에서 물질을 조합하고 [반응 시작]을 눌러 이 반응을 잠금 해제하세요!
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};
