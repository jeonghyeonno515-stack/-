import React, { useEffect, useRef, useState } from 'react';
import { Atom3D, Molecule3DModel } from '../types';
import { Eye, Rotate3d, Sparkles, X } from 'lucide-react';

interface MoleculeViewer3DProps {
  model: Molecule3DModel;
  onClose?: () => void;
  isCompact?: boolean;
}

export const MoleculeViewer3D: React.FC<MoleculeViewer3DProps> = ({
  model,
  onClose,
  isCompact = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [rotX, setRotX] = useState<number>(0.3);
  const [rotY, setRotY] = useState<number>(0.6);
  const [isAutoRotate, setIsAutoRotate] = useState<boolean>(true);
  const [selectedAtom, setSelectedAtom] = useState<Atom3D | null>(null);
  const isDraggingRef = useRef<boolean>(false);
  const lastMousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Auto rotation loop
  useEffect(() => {
    if (!isAutoRotate) return;
    const interval = setInterval(() => {
      setRotY((prev) => prev + 0.015);
      setRotX((prev) => prev + 0.005);
    }, 30);
    return () => clearInterval(interval);
  }, [isAutoRotate]);

  // Render 3D Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const scale = isCompact ? 1.4 : 1.8;

    // Clear
    ctx.clearRect(0, 0, width, height);

    // 3D rotation math
    const cosX = Math.cos(rotX);
    const sinX = Math.sin(rotX);
    const cosY = Math.cos(rotY);
    const sinY = Math.sin(rotY);

    const projectedAtoms = model.atoms.map((atom) => {
      // Y-axis rotation
      const x1 = atom.x * cosY + atom.z * sinY;
      const y1 = atom.y;
      const z1 = -atom.x * sinY + atom.z * cosY;

      // X-axis rotation
      const x2 = x1;
      const y2 = y1 * cosX - z1 * sinX;
      const z2 = y1 * sinX + z1 * cosX;

      // Perspective projection
      const cameraDistance = 350;
      const fov = cameraDistance / (cameraDistance + z2);

      return {
        ...atom,
        projX: centerX + x2 * scale * fov,
        projY: centerY + y2 * scale * fov,
        projZ: z2,
        projRadius: Math.max(10, atom.radius * scale * fov * 0.45),
      };
    });

    // Draw Bonds First
    model.bonds.forEach((bond) => {
      const atomA = projectedAtoms.find((a) => a.id === bond.from);
      const atomB = projectedAtoms.find((a) => a.id === bond.to);
      if (!atomA || !atomB) return;

      const dx = atomB.projX - atomA.projX;
      const dy = atomB.projY - atomA.projY;
      const len = Math.hypot(dx, dy);
      if (len === 0) return;

      const normX = -dy / len;
      const normY = dx / len;

      ctx.save();
      const avgZ = (atomA.projZ + atomB.projZ) / 2;
      const alpha = Math.max(0.4, Math.min(1, 0.8 + avgZ / 200));

      if (bond.order === 1) {
        // Single bond
        ctx.strokeStyle = `rgba(148, 163, 184, ${alpha})`;
        ctx.lineWidth = Math.max(4, 7 * (350 / (350 + avgZ)));
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(atomA.projX, atomA.projY);
        ctx.lineTo(atomB.projX, atomB.projY);
        ctx.stroke();
      } else if (bond.order === 2) {
        // Double bond
        const offset = 4;
        ctx.strokeStyle = `rgba(148, 163, 184, ${alpha})`;
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';

        ctx.beginPath();
        ctx.moveTo(atomA.projX + normX * offset, atomA.projY + normY * offset);
        ctx.lineTo(atomB.projX + normX * offset, atomB.projY + normY * offset);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(atomA.projX - normX * offset, atomA.projY - normY * offset);
        ctx.lineTo(atomB.projX - normX * offset, atomB.projY - normY * offset);
        ctx.stroke();
      }
      ctx.restore();
    });

    // Sort atoms by Z-depth (painter's algorithm)
    const sortedAtoms = [...projectedAtoms].sort((a, b) => a.projZ - b.projZ);

    // Draw Spheres with 3D Gradients & Shadows
    sortedAtoms.forEach((atom) => {
      ctx.save();

      // Shadow
      ctx.beginPath();
      ctx.arc(atom.projX + 4, atom.projY + 6, atom.projRadius, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.fill();

      // Sphere radial gradient
      const grad = ctx.createRadialGradient(
        atom.projX - atom.projRadius * 0.35,
        atom.projY - atom.projRadius * 0.35,
        atom.projRadius * 0.1,
        atom.projX,
        atom.projY,
        atom.projRadius
      );

      grad.addColorStop(0, '#FFFFFF');
      grad.addColorStop(0.35, atom.color);
      grad.addColorStop(1, '#0f172a');

      ctx.beginPath();
      ctx.arc(atom.projX, atom.projY, atom.projRadius, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();

      // Outer glow for key elements
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Symbol text inside atom
      ctx.fillStyle = atom.element === 'H' ? '#0f172a' : '#ffffff';
      ctx.font = `bold ${Math.max(10, atom.projRadius * 0.7)}px system-ui, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(atom.element, atom.projX, atom.projY + 1);

      ctx.restore();
    });
  }, [model, rotX, rotY, isCompact]);

  // Mouse / Touch handlers for 3D rotation
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    setIsAutoRotate(false);
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastMousePosRef.current.x;
    const dy = e.clientY - lastMousePosRef.current.y;
    setRotY((prev) => prev + dx * 0.01);
    setRotX((prev) => prev - dy * 0.01);
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      isDraggingRef.current = true;
      setIsAutoRotate(false);
      lastMousePosRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDraggingRef.current || e.touches.length === 0) return;
    const dx = e.touches[0].clientX - lastMousePosRef.current.x;
    const dy = e.touches[0].clientY - lastMousePosRef.current.y;
    setRotY((prev) => prev + dx * 0.015);
    setRotX((prev) => prev - dy * 0.015);
    lastMousePosRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  return (
    <div
      id="molecule-viewer-container"
      className="relative flex flex-col bg-slate-900/95 border border-cyan-500/30 rounded-2xl p-4 shadow-2xl backdrop-blur-md text-slate-100 overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100">{model.koreanName}</h3>
              <span className="px-2 py-0.5 text-xs font-mono rounded bg-cyan-950 text-cyan-300 border border-cyan-700/50">
                {model.formula}
              </span>
            </div>
            <p className="text-xs text-slate-400">{model.geometry} • {model.bondType}</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            id="toggle-autorotate-btn"
            onClick={() => setIsAutoRotate(!isAutoRotate)}
            title={isAutoRotate ? '자동 회전 멈춤' : '자동 회전 시작'}
            className={`p-2 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
              isAutoRotate
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Rotate3d className="w-4 h-4" />
            <span className="hidden sm:inline">{isAutoRotate ? '자동회전 중' : '회전 고정'}</span>
          </button>
          {onClose && (
            <button
              id="close-viewer-btn"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 3D Canvas Stage */}
      <div
        className="relative flex items-center justify-center bg-radial from-slate-800/60 to-slate-950/90 rounded-xl border border-slate-800/80 cursor-grab active:cursor-grabbing select-none overflow-hidden my-2"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
      >
        <canvas
          ref={canvasRef}
          width={isCompact ? 280 : 340}
          height={isCompact ? 180 : 230}
          className="w-full max-h-56 block touch-none"
        />

        {/* Drag Hint overlay */}
        <div className="absolute bottom-2 left-2 text-[11px] text-slate-400/80 bg-slate-950/70 px-2 py-1 rounded-md pointer-events-none backdrop-blur-sm border border-slate-800 flex items-center gap-1">
          <Eye className="w-3 h-3 text-cyan-400" />
          <span>마우스나 손가락으로 드래그하여 360° 회전</span>
        </div>

        {model.bondAngle && (
          <div className="absolute top-2 right-2 text-[11px] font-mono text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/60">
            결합각: {model.bondAngle}
          </div>
        )}
      </div>

      {/* Description & Scientific explanation */}
      <div className="mt-2 text-xs text-slate-300 leading-relaxed bg-slate-800/50 p-2.5 rounded-xl border border-slate-800">
        <p className="font-medium text-slate-200 mb-1">🔬 구조 및 특징:</p>
        <p>{model.description}</p>
      </div>

      {/* Element Legend */}
      <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-slate-400 pt-1">
        {Array.from(new Set(model.atoms.map((a) => a.element))).map((el) => {
          const sample = model.atoms.find((a) => a.element === el);
          return (
            <div
              key={el}
              className="flex items-center gap-1.5 bg-slate-800/80 px-2 py-1 rounded-md border border-slate-700/60"
            >
              <span
                className="w-3 h-3 rounded-full inline-block shadow-sm"
                style={{ backgroundColor: sample?.color || '#fff' }}
              />
              <span className="text-slate-200 font-medium">{sample?.name || el}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
