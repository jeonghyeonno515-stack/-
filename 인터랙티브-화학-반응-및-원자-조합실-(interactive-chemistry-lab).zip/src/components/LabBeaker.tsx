import React, { useEffect, useState } from 'react';
import { BeakerSubstance, Substance } from '../types';
import { calculateLiquidState, SUBSTANCES } from '../utils/chemistryData';
import {
  Flame,
  Zap,
  RotateCw,
  Trash2,
  Thermometer,
  Activity,
  Droplets,
  Plus,
} from 'lucide-react';
import { soundManager } from '../utils/audio';

interface LabBeakerProps {
  contents: { [substanceId: string]: number };
  temperature: number;
  isHeating: boolean;
  isElectrifying: boolean;
  isReacting: boolean;
  onToggleHeat: () => void;
  onToggleElectricity: () => void;
  onTriggerReaction: () => void;
  onClearBeaker: () => void;
  onDropSubstance: (substanceId: string) => void;
  onOpenPhGuide: () => void;
}

export const LabBeaker: React.FC<LabBeakerProps> = ({
  contents,
  temperature,
  isHeating,
  isElectrifying,
  isReacting,
  onToggleHeat,
  onToggleElectricity,
  onTriggerReaction,
  onClearBeaker,
  onDropSubstance,
  onOpenPhGuide,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const liquidState = calculateLiquidState(contents);

  // Calculate liquid fill percentage (20% min to 85% max)
  const totalItems: number = Object.values(contents).reduce<number>((a, b) => a + (Number(b) || 0), 0);
  const fillPercentage = totalItems === 0 ? 0 : Math.min(85, 20 + totalItems * 8);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const subId = e.dataTransfer.getData('text/plain');
    if (subId) {
      onDropSubstance(subId);
    }
  };

  // Generate bubbles when reacting, boiling, or electrifying
  const bubbleCount = isReacting || isHeating || isElectrifying ? 16 : totalItems > 0 ? 5 : 0;

  return (
    <div
      id="lab-beaker-workspace"
      className="relative flex flex-col items-center justify-between w-full h-full bg-slate-900/90 border border-slate-800/80 rounded-2xl p-4 shadow-xl backdrop-blur-md overflow-hidden"
    >
      {/* Top Status Bar: pH meter & Temp */}
      <div className="w-full flex items-center justify-between gap-2 border-b border-slate-800 pb-3 z-10">
        {/* pH Sensor Box */}
        <button
          id="ph-sensor-btn"
          onClick={onOpenPhGuide}
          className="flex items-center gap-2.5 bg-slate-950/80 hover:bg-slate-800/90 border border-cyan-500/30 px-3 py-1.5 rounded-xl transition-all shadow-inner group"
          title="클릭하여 pH 스케일 가이드 보기"
        >
          <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
          <div className="text-left">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider flex items-center gap-1 font-semibold">
              <span>디지털 pH 프로브</span>
              <span className="text-cyan-400 text-[9px] group-hover:underline">[가이드]</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-mono font-black text-cyan-300">
                pH {liquidState.ph.toFixed(1)}
              </span>
              <span
                className="w-3 h-3 rounded-full shadow-sm border border-white/40 inline-block"
                style={{ backgroundColor: liquidState.liquidColor }}
              />
              <span className="text-xs text-slate-300 font-medium truncate max-w-[120px]">
                {liquidState.indicatorColorName}
              </span>
            </div>
          </div>
        </button>

        {/* Temperature Gauge */}
        <div
          id="temperature-gauge"
          className="flex items-center gap-2 bg-slate-950/80 border border-amber-500/30 px-3 py-1.5 rounded-xl shadow-inner"
        >
          <Thermometer
            className={`w-4 h-4 ${
              temperature > 40 ? 'text-rose-500 animate-bounce' : 'text-amber-400'
            }`}
          />
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
              실험실 온도
            </div>
            <div
              className={`text-lg font-mono font-black ${
                temperature > 60
                  ? 'text-rose-400'
                  : temperature > 35
                  ? 'text-amber-300'
                  : 'text-slate-200'
              }`}
            >
              {temperature.toFixed(1)} °C
            </div>
          </div>
        </div>
      </div>

      {/* Center Beaker Visual Stage */}
      <div
        className="relative flex-1 w-full flex items-center justify-center my-2 select-none"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {/* Drag Drop Highlight Glow */}
        {isDragOver && (
          <div className="absolute inset-0 z-30 rounded-2xl border-2 border-dashed border-cyan-400 bg-cyan-500/10 flex items-center justify-center pointer-events-none backdrop-blur-xs">
            <div className="text-cyan-300 font-bold text-sm bg-slate-950/90 px-4 py-2 rounded-xl shadow-lg border border-cyan-400/50 flex items-center gap-2 animate-bounce">
              <Plus className="w-5 h-5 text-cyan-400" />
              <span>비커에 물질 투입하기</span>
            </div>
          </div>
        )}

        {/* Electrodes (Visible in electricity mode) */}
        {isElectrifying && (
          <div className="absolute top-4 z-20 flex gap-12 pointer-events-none">
            {/* Anode (+) */}
            <div className="flex flex-col items-center animate-pulse">
              <span className="text-[10px] font-bold text-rose-400 bg-rose-950/80 px-1 rounded border border-rose-600 mb-0.5">
                (+) 극 [산소 O₂]
              </span>
              <div className="w-2 h-24 bg-gradient-to-b from-slate-400 to-amber-600 rounded-b shadow-lg border border-slate-300" />
              <div className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping mt-1" />
            </div>
            {/* Cathode (-) */}
            <div className="flex flex-col items-center animate-pulse">
              <span className="text-[10px] font-bold text-cyan-400 bg-cyan-950/80 px-1 rounded border border-cyan-600 mb-0.5">
                (-) 극 [수소 H₂]
              </span>
              <div className="w-2 h-24 bg-gradient-to-b from-slate-400 to-cyan-600 rounded-b shadow-lg border border-slate-300" />
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping mt-1" />
            </div>
          </div>
        )}

        {/* Reaction Sparkles / Explosion burst FX */}
        {isReacting && (
          <div className="absolute inset-0 z-40 flex items-center justify-center pointer-events-none">
            <div className="w-48 h-48 rounded-full bg-amber-400/30 blur-2xl animate-ping" />
            <div className="w-32 h-32 rounded-full bg-rose-500/40 blur-xl animate-pulse" />
          </div>
        )}

        {/* Physical Glass Beaker Container */}
        <div
          id="glass-beaker"
          className="relative w-52 sm:w-60 h-64 sm:h-72 rounded-b-3xl border-x-4 border-b-4 border-t-2 border-slate-400/60 bg-gradient-to-b from-slate-800/10 via-slate-700/10 to-slate-900/40 shadow-2xl flex flex-col justify-end overflow-hidden backdrop-blur-xs"
        >
          {/* Glass Rim lip */}
          <div className="absolute top-0 left-[-4px] right-[-4px] h-3 bg-slate-300/30 rounded-t-lg border border-slate-300/40" />

          {/* Volume Graduation ticks */}
          <div className="absolute top-6 left-2 flex flex-col justify-between h-48 pointer-events-none z-10 select-none">
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400/80">
              <span className="w-4 h-0.5 bg-slate-400/60" />
              <span>400 mL</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400/80">
              <span className="w-3 h-0.5 bg-slate-400/60" />
              <span>300 mL</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400/80">
              <span className="w-4 h-0.5 bg-slate-400/60" />
              <span>200 mL</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400/80">
              <span className="w-3 h-0.5 bg-slate-400/60" />
              <span>100 mL</span>
            </div>
          </div>

          {/* Liquid Chamber */}
          {fillPercentage > 0 ? (
            <div
              className="relative w-full transition-all duration-700 ease-out flex flex-col justify-end overflow-hidden"
              style={{
                height: `${fillPercentage}%`,
                background: `linear-gradient(180deg, ${liquidState.liquidColor} 0%, ${liquidState.liquidColor} 100%)`,
                boxShadow: `0 0 25px ${liquidState.liquidColor}`,
              }}
            >
              {/* Meniscus Wave top surface */}
              <div className="absolute top-0 left-0 right-0 h-4 bg-white/25 rounded-[100%] blur-[1px] transform -translate-y-1/2" />

              {/* Rising Bubbles Effect */}
              {Array.from({ length: bubbleCount }).map((_, i) => (
                <div
                  key={i}
                  className="absolute rounded-full bg-white/60 border border-white/80 animate-rise"
                  style={{
                    width: `${Math.random() * 8 + 4}px`,
                    height: `${Math.random() * 8 + 4}px`,
                    left: `${Math.random() * 80 + 10}%`,
                    bottom: `${Math.random() * 20}%`,
                    animationDuration: `${1.2 + Math.random() * 1.5}s`,
                    animationDelay: `${Math.random() * 1.2}s`,
                    animationIterationCount: 'infinite',
                  }}
                />
              ))}

              {/* Solid precipitate / sediment settling at bottom if salts or metals */}
              {(contents['CaCO3'] || contents['Fe'] || contents['Cu'] || contents['C']) && (
                <div className="w-full h-3 bg-slate-900/60 border-t border-slate-700/50 flex justify-center items-center gap-1">
                  <span className="text-[9px] text-slate-300 font-mono">침전물 / 고체 입자</span>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center text-slate-500">
              <Droplets className="w-8 h-8 text-slate-600 mb-2 opacity-60" />
              <p className="text-xs font-medium text-slate-400">비커가 비어있습니다</p>
              <p className="text-[11px] text-slate-500 mt-1">
                오른쪽 보관함에서 물질을 클릭하거나 드래그하여 투입하세요!
              </p>
            </div>
          )}

          {/* Glass Reflection highlights */}
          <div className="absolute top-0 right-3 bottom-0 w-2 bg-gradient-to-b from-white/20 via-white/5 to-transparent pointer-events-none rounded-full" />
          <div className="absolute top-0 left-3 bottom-0 w-1 bg-gradient-to-b from-white/20 via-white/5 to-transparent pointer-events-none rounded-full" />
        </div>
      </div>

      {/* Burner Flame Visual Base */}
      <div className="relative w-full flex flex-col items-center justify-center h-12 -mt-2">
        {isHeating ? (
          <div className="flex flex-col items-center animate-pulse">
            {/* Animated Bunsen Flame */}
            <div className="relative flex justify-center items-end">
              <div className="w-8 h-10 bg-gradient-to-t from-blue-600 via-cyan-400 to-amber-300 rounded-t-full blur-xs animate-bounce" />
              <div className="absolute w-4 h-6 bg-gradient-to-t from-blue-500 to-white rounded-t-full" />
            </div>
            {/* Burner nozzle */}
            <div className="w-16 h-2 bg-slate-700 rounded-t border border-slate-600" />
            <div className="w-24 h-1.5 bg-slate-800 rounded-b shadow" />
          </div>
        ) : (
          <div className="flex flex-col items-center opacity-40">
            <div className="w-16 h-2 bg-slate-800 rounded-t border border-slate-700" />
            <div className="w-24 h-1.5 bg-slate-900 rounded-b" />
          </div>
        )}
      </div>

      {/* Current Contents Chips List */}
      <div className="w-full bg-slate-950/70 rounded-xl p-2 border border-slate-800 min-h-[52px] mb-3 flex flex-wrap items-center gap-1.5">
        <span className="text-[11px] font-semibold text-slate-400 pl-1 mr-1">비커 속 물질:</span>
        {totalItems === 0 ? (
          <span className="text-xs text-slate-500 italic">물질이 없습니다.</span>
        ) : (
          Object.entries(contents).map(([subId, rawCount]) => {
            const count = Number(rawCount) || 0;
            const sub = SUBSTANCES.find((s) => s.id === subId);
            if (!sub || count <= 0) return null;
            return (
              <span
                key={subId}
                className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 shadow-sm"
              >
                <span className="text-cyan-400 font-mono">{sub.formulaDisplay}</span>
                <span className="text-slate-400 text-[10px]">({sub.name})</span>
                <span className="bg-slate-700 text-cyan-300 text-[10px] px-1 rounded font-mono">
                  x{count}
                </span>
              </span>
            );
          })
        )}
      </div>

      {/* Action Controls Toolbar */}
      <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-800">
        {/* Heat Burner Button */}
        <button
          id="heat-burner-btn"
          onClick={() => {
            soundManager.playBurner();
            onToggleHeat();
          }}
          className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 ${
            isHeating
              ? 'bg-gradient-to-r from-amber-600 to-rose-600 text-white shadow-amber-500/30 border border-amber-400'
              : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700'
          }`}
        >
          <Flame className={`w-4 h-4 ${isHeating ? 'animate-bounce text-amber-200' : 'text-amber-400'}`} />
          <span>{isHeating ? '가열 중단' : '🔥 열 가하기'}</span>
        </button>

        {/* Electricity Button */}
        <button
          id="electrolysis-btn"
          onClick={() => {
            soundManager.playSpark();
            onToggleElectricity();
          }}
          className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 ${
            isElectrifying
              ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-cyan-500/30 border border-cyan-400'
              : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700'
          }`}
        >
          <Zap className={`w-4 h-4 ${isElectrifying ? 'animate-pulse text-cyan-200' : 'text-cyan-400'}`} />
          <span>{isElectrifying ? '전류 차단' : '⚡ 전기 분해'}</span>
        </button>

        {/* Trigger Reaction Button */}
        <button
          id="trigger-reaction-btn"
          onClick={() => {
            soundManager.playClick();
            onTriggerReaction();
          }}
          disabled={totalItems === 0}
          className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 ${
            totalItems > 0
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-500/30 border border-emerald-400/50'
              : 'bg-slate-800/50 text-slate-500 border border-slate-800 cursor-not-allowed'
          }`}
        >
          <RotateCw className={`w-4 h-4 ${isReacting ? 'animate-spin' : ''}`} />
          <span>🧪 반응 시작</span>
        </button>

        {/* Clear Beaker Button */}
        <button
          id="clear-beaker-btn"
          onClick={() => {
            soundManager.playPour();
            onClearBeaker();
          }}
          disabled={totalItems === 0}
          className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 ${
            totalItems > 0
              ? 'bg-slate-800 hover:bg-rose-950/80 hover:text-rose-300 text-slate-300 border border-slate-700 hover:border-rose-700/60'
              : 'bg-slate-800/40 text-slate-600 border border-slate-800 cursor-not-allowed'
          }`}
        >
          <Trash2 className="w-4 h-4" />
          <span>비커 비우기</span>
        </button>
      </div>
    </div>
  );
};
