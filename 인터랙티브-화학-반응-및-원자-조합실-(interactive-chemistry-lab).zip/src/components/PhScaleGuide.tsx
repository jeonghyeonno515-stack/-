import React, { useState } from 'react';
import { Activity, X, Droplets, Info, Sparkles, Check } from 'lucide-react';

interface PhScaleGuideProps {
  onClose: () => void;
  currentPh: number;
}

export const PhScaleGuide: React.FC<PhScaleGuideProps> = ({ onClose, currentPh }) => {
  const [selectedIndicator, setSelectedIndicator] = useState<'universal' | 'btb' | 'phenolphthalein' | 'litmus'>('universal');

  const everydayItems = [
    { ph: 1, name: '위액 / 염산(HCl)', type: '강산', color: '#EF4444' },
    { ph: 2, name: '레몬즙 / 식초', type: '강산', color: '#F87171' },
    { ph: 3, name: '탄산음료 / 오렌지', type: '산성', color: '#FB923C' },
    { ph: 4, name: '토마토 주스 / 산성비', type: '산성', color: '#FBBF24' },
    { ph: 5, name: '블랙 커피', type: '약산', color: '#FACC15' },
    { ph: 6, name: '우유 / 타액(침)', type: '약산', color: '#EAB308' },
    { ph: 7, name: '순수한 물 (H₂O)', type: '중성', color: '#22C55E' },
    { ph: 8, name: '바닷물 / 사람의 혈액', type: '약염기', color: '#06B6D4' },
    { ph: 9, name: '베이킹소다 수용액', type: '약염기', color: '#0EA5E9' },
    { ph: 10, name: '제산제 (위장약)', type: '염기성', color: '#3B82F6' },
    { ph: 11, name: '암모니아수 / 비눗물', type: '염기성', color: '#6366F1' },
    { ph: 12, name: '치약 / 석회수', type: '강염기', color: '#8B5CF6' },
    { ph: 13, name: '표백제 (락스)', type: '강염기', color: '#A855F7' },
    { ph: 14, name: '수산화나트륨(NaOH)', type: '강염기', color: '#C084FC' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div
        id="ph-guide-modal"
        className="relative w-full max-w-2xl bg-slate-900 border border-cyan-500/40 rounded-2xl shadow-2xl p-5 text-slate-100 flex flex-col gap-4 max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                pH 스케일 & 지시약 색상 비교 가이드
              </h2>
              <p className="text-xs text-slate-400">
                수용액 속 수소 이온 농도(pH 0~14)에 따른 액성과 지시약의 색 변화
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Beaker pH Highlight */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-cyan-500/30">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-semibold">현재 비커 용액의 pH:</span>
            <span className="text-xl font-mono font-black text-cyan-300">
              pH {currentPh.toFixed(1)}
            </span>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-800 text-slate-200 border border-slate-700">
            {currentPh < 7 ? '🔴 산성 (Acidic)' : currentPh > 7 ? '🔵 염기성 (Basic)' : '🟢 중성 (Neutral)'}
          </span>
        </div>

        {/* Indicator Switcher */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedIndicator('universal')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              selectedIndicator === 'universal'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            🌈 만능 지시약 (Universal)
          </button>
          <button
            onClick={() => setSelectedIndicator('btb')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              selectedIndicator === 'btb'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/50'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            🧪 BTB 용액
          </button>
          <button
            onClick={() => setSelectedIndicator('phenolphthalein')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              selectedIndicator === 'phenolphthalein'
                ? 'bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/50'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            🌸 페놀프탈레인
          </button>
          <button
            onClick={() => setSelectedIndicator('litmus')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              selectedIndicator === 'litmus'
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/50'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            📄 리트머스 종이
          </button>
        </div>

        {/* Dynamic Color Scale Bar */}
        <div className="flex flex-col gap-1.5 bg-slate-950 p-3 rounded-xl border border-slate-800">
          <div className="flex justify-between text-[11px] font-mono text-slate-400 px-1 font-bold">
            <span className="text-red-400">pH 0 (강산)</span>
            <span className="text-amber-400">pH 4 (약산)</span>
            <span className="text-emerald-400">pH 7 (중성)</span>
            <span className="text-blue-400">pH 10 (약염기)</span>
            <span className="text-purple-400">pH 14 (강염기)</span>
          </div>

          {/* Color Gradient Strip */}
          <div className="relative h-7 w-full rounded-lg overflow-hidden border border-slate-700 shadow-inner flex">
            {selectedIndicator === 'universal' && (
              <div
                className="w-full h-full"
                style={{
                  background:
                    'linear-gradient(to right, #EF4444 0%, #F97316 25%, #EAB308 40%, #22C55E 50%, #06B6D4 60%, #3B82F6 75%, #9333EA 100%)',
                }}
              />
            )}
            {selectedIndicator === 'btb' && (
              <div
                className="w-full h-full"
                style={{
                  background:
                    'linear-gradient(to right, #EAB308 0%, #EAB308 45%, #22C55E 50%, #2563EB 55%, #2563EB 100%)',
                }}
              />
            )}
            {selectedIndicator === 'phenolphthalein' && (
              <div
                className="w-full h-full"
                style={{
                  background:
                    'linear-gradient(to right, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.2) 58%, #EC4899 65%, #DB2777 100%)',
                }}
              />
            )}
            {selectedIndicator === 'litmus' && (
              <div
                className="w-full h-full"
                style={{
                  background:
                    'linear-gradient(to right, #EF4444 0%, #EF4444 48%, #64748B 50%, #3B82F6 52%, #3B82F6 100%)',
                }}
              />
            )}

            {/* Current pH cursor marker */}
            <div
              className="absolute top-0 bottom-0 w-2.5 bg-white border-2 border-slate-900 rounded shadow-md transform -translate-x-1/2 transition-all duration-300"
              style={{ left: `${Math.min(100, Math.max(0, (currentPh / 14) * 100))}%` }}
            />
          </div>

          {/* Indicator Rules description */}
          <div className="text-[11px] text-slate-300 mt-1">
            {selectedIndicator === 'universal' && (
              <p>🔴 <strong>만능 지시약:</strong> 산성(빨강/주황) ➔ 중성(초록) ➔ 염기성(파랑/보라)</p>
            )}
            {selectedIndicator === 'btb' && (
              <p>🧪 <strong>BTB 용액:</strong> 산성(노랑) ➔ 중성(초록) ➔ 염기성(파랑) [숨 불어넣기 실험]</p>
            )}
            {selectedIndicator === 'phenolphthalein' && (
              <p>🌸 <strong>페놀프탈레인:</strong> 산성/중성(무색) ➔ 염기성(선명한 붉은 분홍색)</p>
            )}
            {selectedIndicator === 'litmus' && (
              <p>📄 <strong>리트머스 종이:</strong> 푸른 종이가 붉게(산성) / 붉은 종이가 푸르게(염기성)</p>
            )}
          </div>
        </div>

        {/* Everyday Substances Grid */}
        <div>
          <h3 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>우리 주변 일상 속 물질들의 pH</span>
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1">
            {everydayItems.map((item) => (
              <div
                key={item.ph}
                className="flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-slate-200 font-medium truncate max-w-[110px]">{item.name}</span>
                </div>
                <span className="font-mono text-cyan-400 font-bold shrink-0">pH {item.ph}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
        >
          가이드 닫기
        </button>
      </div>
    </div>
  );
};
