import React, { useState } from 'react';
import { Sparkles, X, Plus, Trash2, CheckCircle2, RotateCcw } from 'lucide-react';
import { soundManager } from '../utils/audio';
import confetti from 'canvas-confetti';

interface AtomBuilderMiniProps {
  onClose: () => void;
}

interface PlacedAtom {
  id: string;
  symbol: string;
  name: string;
  color: string;
  valenceElectrons: number;
}

export const AtomBuilderMini: React.FC<AtomBuilderMiniProps> = ({ onClose }) => {
  const [placedAtoms, setPlacedAtoms] = useState<PlacedAtom[]>([]);
  const [assembledMolecule, setAssembledMolecule] = useState<{
    formula: string;
    name: string;
    description: string;
  } | null>(null);

  const availableAtoms = [
    { symbol: 'H', name: '수소', color: '#E0F2FE', valenceElectrons: 1, maxBond: 1 },
    { symbol: 'O', name: '산소', color: '#EF4444', valenceElectrons: 6, maxBond: 2 },
    { symbol: 'C', name: '탄소', color: '#64748B', valenceElectrons: 4, maxBond: 4 },
    { symbol: 'Na', name: '나트륨', color: '#A855F7', valenceElectrons: 1, maxBond: 1 },
    { symbol: 'Cl', name: '염소', color: '#10B981', valenceElectrons: 7, maxBond: 1 },
  ];

  const handleAddAtom = (atom: typeof availableAtoms[0]) => {
    soundManager.playPour();
    const newAtom: PlacedAtom = {
      id: `${atom.symbol}_${Date.now()}_${Math.random()}`,
      symbol: atom.symbol,
      name: atom.name,
      color: atom.color,
      valenceElectrons: atom.valenceElectrons,
    };
    setPlacedAtoms((prev) => [...prev, newAtom]);
    setAssembledMolecule(null);
  };

  const handleClear = () => {
    soundManager.playClick();
    setPlacedAtoms([]);
    setAssembledMolecule(null);
  };

  const handleCombine = () => {
    soundManager.playClick();
    // Count symbols
    const counts: { [key: string]: number } = {};
    placedAtoms.forEach((a) => {
      counts[a.symbol] = (counts[a.symbol] || 0) + 1;
    });

    const H = counts['H'] || 0;
    const O = counts['O'] || 0;
    const C = counts['C'] || 0;
    const Na = counts['Na'] || 0;
    const Cl = counts['Cl'] || 0;

    let result = null;

    if (H === 2 && O === 1 && C === 0 && Na === 0 && Cl === 0) {
      result = {
        formula: 'H₂O',
        name: '물 (Water)',
        description: '산소 1개가 수소 2개와 각각 전자 1쌍씩을 공유하여 안정된 물 분자를 완성했습니다!',
      };
    } else if (Na === 1 && Cl === 1 && H === 0 && O === 0 && C === 0) {
      result = {
        formula: 'NaCl',
        name: '염화나트륨 (소금)',
        description: '나트륨이 전자 1개를 염소에게 건네주어 Na⁺ 와 Cl⁻ 이온 결합을 형성했습니다!',
      };
    } else if (C === 1 && O === 2 && H === 0 && Na === 0 && Cl === 0) {
      result = {
        formula: 'CO₂',
        name: '이산화탄소 (Carbon Dioxide)',
        description: '탄소가 양쪽 산소와 각각 전자 2쌍씩 이중 결합을 하여 직선형 분자를 만들었습니다!',
      };
    } else if (H === 1 && Cl === 1 && O === 0 && C === 0 && Na === 0) {
      result = {
        formula: 'HCl',
        name: '염화수소 (Hydrochloric Acid)',
        description: '수소와 염소가 전자 1쌍을 공유하여 극성 공유 결합 분자를 형성했습니다!',
      };
    } else if (H === 2 && O === 0 && C === 0 && Na === 0 && Cl === 0) {
      result = {
        formula: 'H₂',
        name: '수소 기체 분자 (Hydrogen)',
        description: '수소 원자 2개가 전자 1쌍을 나누어가져 헬륨과 같은 안정한 상태가 되었습니다!',
      };
    } else if (O === 2 && H === 0 && C === 0 && Na === 0 && Cl === 0) {
      result = {
        formula: 'O₂',
        name: '산소 기체 분자 (Oxygen)',
        description: '산소 원자 2개가 이중 결합을 통해 각각 최외각 전자 8개(옥텟 규칙)를 만족했습니다!',
      };
    } else {
      result = {
        formula: '불안정한 조합',
        name: '옥텟 규칙 불만족',
        description: '원자들의 최외각 전자가 8개(수소는 2개)를 만족하지 않아 안정한 분자를 이룰 수 없습니다. 원자 개수를 조절해보세요!',
      };
    }

    if (result.name !== '옥텟 규칙 불만족') {
      soundManager.playSuccess();
      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      } catch {
        // ignore
      }
    }
    setAssembledMolecule(result);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div
        id="atom-builder-dialog"
        className="relative w-full max-w-xl bg-slate-900 border border-purple-500/40 rounded-2xl shadow-2xl p-5 text-slate-100 flex flex-col gap-4 max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                원자 조합 & 옥텟 규칙 연구실 (Atom & Bond Builder)
              </h2>
              <p className="text-xs text-slate-400">
                원자들을 작업대에 배치하고 결합 버튼을 눌러 안정한 분자를 합성해보세요!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Atom Palette */}
        <div className="flex flex-col gap-2">
          <span className="text-xs font-semibold text-slate-300">원자 선택기 (클릭하여 추가):</span>
          <div className="grid grid-cols-5 gap-2">
            {availableAtoms.map((atom) => (
              <button
                key={atom.symbol}
                onClick={() => handleAddAtom(atom)}
                className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 hover:border-purple-400 transition-all active:scale-95 group"
              >
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm text-slate-900 shadow-md mb-1 group-hover:scale-110 transition-transform"
                  style={{ backgroundColor: atom.color }}
                >
                  {atom.symbol}
                </div>
                <span className="text-[11px] font-medium text-slate-200">{atom.name}</span>
                <span className="text-[9px] text-slate-400">최외각 e⁻: {atom.valenceElectrons}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Assembly Stage */}
        <div className="relative min-h-[160px] bg-slate-950 rounded-2xl border border-slate-800 p-4 flex flex-wrap items-center justify-center gap-3">
          {placedAtoms.length === 0 ? (
            <span className="text-xs text-slate-500 italic">
              위의 원자 버튼을 클릭하여 작업대에 원자들을 올려놓으세요. (예: H + H + O)
            </span>
          ) : (
            placedAtoms.map((atom, idx) => (
              <div
                key={atom.id}
                className="flex flex-col items-center animate-scaleIn bg-slate-900/90 border border-slate-700 px-3 py-2 rounded-xl shadow"
              >
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-base text-slate-900 shadow-inner"
                  style={{ backgroundColor: atom.color }}
                >
                  {atom.symbol}
                </div>
                <span className="text-[10px] text-slate-300 mt-1 font-medium">{atom.name}</span>
              </div>
            ))
          )}
        </div>

        {/* Combined Result Banner */}
        {assembledMolecule && (
          <div
            className={`p-3.5 rounded-xl border flex flex-col gap-1.5 animate-fadeIn ${
              assembledMolecule.name !== '옥텟 규칙 불만족'
                ? 'bg-emerald-950/30 border-emerald-500/50 text-emerald-200'
                : 'bg-rose-950/30 border-rose-500/50 text-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span className="font-bold text-sm">
                {assembledMolecule.formula} - {assembledMolecule.name}
              </span>
            </div>
            <p className="text-xs leading-relaxed opacity-90 pl-7">
              {assembledMolecule.description}
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800">
          <button
            onClick={handleClear}
            disabled={placedAtoms.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>초기화</span>
          </button>

          <button
            onClick={handleCombine}
            disabled={placedAtoms.length === 0}
            className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 disabled:opacity-40 transition-all active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>원자 결합 실행 (Combine Atoms)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
