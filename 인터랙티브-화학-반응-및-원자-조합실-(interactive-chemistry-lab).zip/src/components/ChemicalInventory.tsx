import React, { useState } from 'react';
import { Substance, SubstanceCategory } from '../types';
import { SUBSTANCES } from '../utils/chemistryData';
import {
  FlaskConical,
  Plus,
  Info,
  Search,
  Box,
  Droplets,
  Wind,
  Layers,
  Sparkles,
  Flame,
} from 'lucide-react';
import { soundManager } from '../utils/audio';

interface ChemicalInventoryProps {
  onAddSubstance: (substanceId: string, amount?: number) => void;
  onInspectSubstance: (substance: Substance) => void;
}

export const ChemicalInventory: React.FC<ChemicalInventoryProps> = ({
  onAddSubstance,
  onInspectSubstance,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: '전체 물질', icon: FlaskConical },
    { id: 'gas', label: '기체 (Gas)', icon: Wind },
    { id: 'metal', label: '금속/고체', icon: Box },
    { id: 'acid_base', label: '산과 염기', icon: Droplets },
    { id: 'indicator', label: '지시약/시약', icon: Sparkles },
    { id: 'salt_compound', label: '염 및 화합물', icon: Layers },
  ];

  const filteredSubstances = SUBSTANCES.filter((sub) => {
    // Category match
    if (selectedCategory === 'gas' && sub.category !== 'gas') return false;
    if (selectedCategory === 'metal' && sub.category !== 'metal') return false;
    if (selectedCategory === 'acid_base' && sub.category !== 'acid' && sub.category !== 'base') return false;
    if (selectedCategory === 'indicator' && sub.category !== 'indicator') return false;
    if (selectedCategory === 'salt_compound' && sub.category !== 'salt' && sub.category !== 'compound' && sub.category !== 'neutral') return false;

    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const nameMatch = sub.name.toLowerCase().includes(q);
      const formulaMatch = sub.formula.toLowerCase().includes(q);
      const engMatch = sub.englishName.toLowerCase().includes(q);
      return nameMatch || formulaMatch || engMatch;
    }
    return true;
  });

  const handleDragStart = (e: React.DragEvent, substanceId: string) => {
    e.dataTransfer.setData('text/plain', substanceId);
    e.dataTransfer.effectAllowed = 'copy';
  };

  return (
    <div
      id="chemical-inventory-shelf"
      className="flex flex-col h-full bg-slate-900/90 border border-slate-800/80 rounded-2xl p-4 shadow-xl backdrop-blur-md overflow-hidden text-slate-100"
    >
      {/* Shelf Header */}
      <div className="flex flex-col gap-2.5 border-b border-slate-800 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-1.5">
                <span>화학 물질 보관함 (Chemical Inventory)</span>
              </h2>
              <p className="text-xs text-slate-400">원소를 클릭하거나 비커로 드래그하여 투입하세요</p>
            </div>
          </div>
          <span className="text-xs font-mono font-semibold px-2 py-1 rounded bg-slate-800 text-cyan-300 border border-slate-700">
            총 {SUBSTANCES.length}종
          </span>
        </div>

        {/* Search Bar */}
        <div className="relative w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="inventory-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="원소 기호(H2, Na, HCl) 또는 이름으로 검색..."
            className="w-full bg-slate-950/80 border border-slate-700/80 focus:border-cyan-500 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none transition-all shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-200"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                id={`cat-btn-${cat.id}`}
                onClick={() => {
                  soundManager.playClick();
                  setSelectedCategory(cat.id);
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                    : 'bg-slate-800/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Chemical Grid Cards */}
      <div className="flex-1 overflow-y-auto pr-1 my-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-2.5">
        {filteredSubstances.map((sub) => {
          return (
            <div
              key={sub.id}
              id={`substance-card-${sub.id}`}
              draggable
              onDragStart={(e) => handleDragStart(e, sub.id)}
              className="group relative flex flex-col justify-between bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 rounded-xl p-3 transition-all shadow-md hover:shadow-cyan-500/10 cursor-grab active:cursor-grabbing"
            >
              {/* Card Top: Formula & State Badge */}
              <div className="flex items-start justify-between gap-1 mb-1">
                <div className="flex items-center gap-2">
                  {/* Formula Badge */}
                  <span
                    className={`font-mono font-black text-base px-2.5 py-0.5 rounded-lg border shadow-sm ${sub.color}`}
                  >
                    {sub.formulaDisplay}
                  </span>
                  <div>
                    <h3 className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                      {sub.name}
                    </h3>
                    <p className="text-[10px] text-slate-400">{sub.englishName}</p>
                  </div>
                </div>

                {/* State Tag */}
                <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded bg-slate-800/90 text-slate-400 border border-slate-700">
                  {sub.stateSymbol}
                </span>
              </div>

              {/* Brief Description */}
              <p className="text-[11px] text-slate-400 line-clamp-2 my-1.5 leading-relaxed">
                {sub.description}
              </p>

              {/* Card Bottom: Quick Actions */}
              <div className="flex items-center justify-between gap-1.5 pt-2 border-t border-slate-800/80">
                {/* 3D / Info Button */}
                <button
                  id={`info-btn-${sub.id}`}
                  onClick={() => onInspectSubstance(sub)}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-cyan-300 px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700/60 transition-colors"
                  title="3D 구조 및 상세 원리 보기"
                >
                  <Info className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{sub.moleculeModel ? '3D 구조' : '상세정보'}</span>
                </button>

                {/* Add to Beaker Buttons (+1, +2) */}
                <div className="flex items-center gap-1">
                  <button
                    id={`add-btn-${sub.id}`}
                    onClick={() => {
                      soundManager.playPour();
                      onAddSubstance(sub.id, 1);
                    }}
                    className="flex items-center gap-1 text-xs font-bold bg-cyan-600/30 hover:bg-cyan-500 text-cyan-200 hover:text-white px-2.5 py-1 rounded-lg border border-cyan-500/40 hover:border-cyan-400 transition-all shadow-sm active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>투입</span>
                  </button>
                  <button
                    id={`add2-btn-${sub.id}`}
                    onClick={() => {
                      soundManager.playPour();
                      onAddSubstance(sub.id, 2);
                    }}
                    className="text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 px-1.5 py-1 rounded-lg border border-slate-700 transition-all active:scale-95"
                    title="2개 투입"
                  >
                    +2
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
