import React from 'react';
import { ChemicalReaction, Substance } from '../types';
import { SUBSTANCES } from '../utils/chemistryData';
import {
  Sparkles,
  Flame,
  Zap,
  TrendingUp,
  BookOpen,
  Eye,
  CheckCircle,
  X,
  Share2,
} from 'lucide-react';
import { MoleculeViewer3D } from './MoleculeViewer3D';

interface ReactionResultModalProps {
  reaction: ChemicalReaction;
  onClose: () => void;
  onInspectProduct: (substance: Substance) => void;
}

export const ReactionResultModal: React.FC<ReactionResultModalProps> = ({
  reaction,
  onClose,
  onInspectProduct,
}) => {
  // Find product substance with 3D model if available
  const productKeys = Object.keys(reaction.products);
  const mainProductSubstance = SUBSTANCES.find(
    (s) => productKeys.includes(s.id) && s.moleculeModel
  ) || SUBSTANCES.find((s) => productKeys.includes(s.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div
        id="reaction-result-dialog"
        className="relative w-full max-w-xl bg-slate-900 border border-cyan-500/40 rounded-2xl shadow-2xl p-5 text-slate-100 flex flex-col gap-4 max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 text-white shadow-lg shadow-rose-500/20 animate-pulse">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-700/60">
                  {reaction.reactionType}
                </span>
                <span
                  className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                    reaction.heatChange === 'exothermic'
                      ? 'bg-rose-950 text-rose-300 border border-rose-700/60'
                      : reaction.heatChange === 'endothermic'
                      ? 'bg-blue-950 text-blue-300 border border-blue-700/60'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {reaction.heatChange === 'exothermic'
                    ? '🔥 발열 반응 (온도 상승)'
                    : reaction.heatChange === 'endothermic'
                    ? '❄️ 흡열 반응 (온도 하강)'
                    : '중립 반응'}
                </span>
              </div>
              <h2 className="text-lg font-black text-slate-100 mt-1">{reaction.title}</h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chemical Equation Big Display */}
        <div className="flex flex-col items-center justify-center p-4 bg-slate-950 rounded-xl border border-cyan-500/30 shadow-inner">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-widest mb-1">
            완성된 화학 반응식 (Balanced Equation)
          </span>
          <div className="text-base sm:text-xl font-mono font-black text-cyan-300 tracking-wider text-center select-all">
            {reaction.balancedEquation}
          </div>
        </div>

        {/* 3D Product Molecule Preview (if available) */}
        {mainProductSubstance && mainProductSubstance.moleculeModel && (
          <div className="w-full">
            <MoleculeViewer3D model={mainProductSubstance.moleculeModel} isCompact={true} />
          </div>
        )}

        {/* Explanation & Curriculum Learning Points */}
        <div className="flex flex-col gap-2.5 bg-slate-800/60 p-3.5 rounded-xl border border-slate-800 text-xs">
          <div className="flex items-start gap-2 text-slate-300 leading-relaxed">
            <BookOpen className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-slate-200 mb-1">🔬 반응 원리 및 해설</p>
              <p>{reaction.explanation}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2 border-t border-slate-700/60 text-slate-400">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              <strong className="text-slate-200">교과 연계 포인트:</strong> {reaction.curriculumPoint}
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between gap-3 pt-2">
          {mainProductSubstance && (
            <button
              onClick={() => {
                onInspectProduct(mainProductSubstance);
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 transition-colors"
            >
              <Eye className="w-4 h-4 text-cyan-400" />
              <span>생성물({mainProductSubstance.name}) 3D 도감 보기</span>
            </button>
          )}

          <button
            id="continue-experiment-btn"
            onClick={onClose}
            className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white shadow-lg shadow-cyan-500/20 transition-all active:scale-95"
          >
            <span>확인 및 다음 실험 계속하기</span>
          </button>
        </div>
      </div>
    </div>
  );
};
